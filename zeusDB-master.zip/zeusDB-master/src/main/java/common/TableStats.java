package common;

import java.util.ArrayList;
import java.util.HashMap;
import net.sf.jsqlparser.schema.Column;
import operator.ScanOperator;

public class TableStats {
  private final String tableName;
  private final ArrayList<Column> outputSchema;
  private final int size;
  private final HashMap<Column, Integer[]> columnStats;

  public TableStats(String tableName) {
    this.tableName = tableName;
    this.outputSchema = DBCatalog.getDB().getTableColumns(tableName);
    this.columnStats = new HashMap<>();
    this.size = generateStats();
  }

  private int generateStats() {
    ScanOperator scan = new ScanOperator(outputSchema);
    Tuple currentTuple = scan.getNextTuple();
    int numTuples = 0;

    for (Column col : outputSchema) {
      columnStats.put(col, new Integer[] {Integer.MAX_VALUE, Integer.MIN_VALUE});
    }

    while (currentTuple != null) {
      for (int i = 0; i < outputSchema.size(); i++) {
        Column currentColumn = outputSchema.get(i);
        int currentElement = currentTuple.getElementAtIndex(i);
        Integer[] currentBounds = columnStats.get(currentColumn);

        if (currentElement < currentBounds[0]) {
          currentBounds[0] = currentElement;
        }
        if (currentElement > currentBounds[1]) {
          currentBounds[1] = currentElement;
        }
      }

      numTuples++;
      currentTuple = scan.getNextTuple();
    }

    return numTuples;
  }

  public int getSize() {
    return size;
  }

  public HashMap<Column, Integer[]> getColumnStats() {
    // Providing an unmodifiable view to prevent external modifications
    return columnStats;
  }

  public ArrayList<Column> getOutputSchema() {
    return outputSchema;
  }

  public String getTableName() {
    return tableName;
  }
}
