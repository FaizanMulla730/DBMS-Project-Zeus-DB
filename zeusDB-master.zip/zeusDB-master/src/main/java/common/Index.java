package common;

import net.sf.jsqlparser.schema.Column;

/** Represents an index associated with a specific column in a database table. */
public class Index {
  private final String indexFilePath;
  private final Column indexColumn;
  private final boolean isClustered;
  private final int order;

  /**
   * Constructs an Index object with the specified parameters.
   *
   * @param indexFilePath The file path where the index data is stored.
   * @param order The order of the tree
   * @param indexColumn The Column object associated with this index.
   * @param isClustered Indicates whether the index is clustered or not.
   */
  public Index(String indexFilePath, int order, Column indexColumn, boolean isClustered) {
    this.indexFilePath = indexFilePath;
    this.order = order;
    this.indexColumn = indexColumn;
    this.isClustered = isClustered;
  }

  /**
   * Gets the file path where the index data is stored.
   *
   * @return String: The file path of the index.
   */
  public String getIndexFilePath() {
    return indexFilePath;
  }

  /**
   * Gets the Column object associated with this index.
   *
   * @return Column: The Column object of the index.
   */
  public Column getIndexColumn() {
    return indexColumn;
  }

  /**
   * Gets the order of the index for multi-column indexes.
   *
   * @return int: The order of the index.
   */
  public int getIndexOrder() {
    return order;
  }

  /**
   * Checks if the index is clustered.
   *
   * @return boolean: If true, the index is clustered; otherwise, it is not.
   */
  public boolean isClustered() {
    return isClustered;
  }
}
