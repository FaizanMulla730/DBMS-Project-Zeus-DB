package common;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import util.StatsWriter;

/**
 * Class to contain information about database - names of tables, schema of each table and file
 * where each table is located.
 *
 * <p>Uses singleton pattern.
 *
 * <p>Assumes dbDirectory has a schema.txt file and a /data subdirectory containing one file per
 * relation, named "relname".
 *
 * <p>Call by using DBCatalog.getDB();
 */
public class DBCatalog {
  private final Logger logger = LogManager.getLogger();
  private static String dbDirectory;
  private static String tempDirectory;
  private static String indexDir;
  private static DBCatalog db = new DBCatalog();
  private final HashMap<String, ArrayList<Column>> tables = new HashMap<>();
  private final HashMap<String, TableStats> allTableStats = new HashMap<>();
  private final HashMap<String, ArrayList<Index>> indexes = new HashMap<>();

  /** Private constructor following singleton pattern */
  private DBCatalog() {}

  /**
   * Instance getter for singleton pattern
   *
   * @return DB catalog instance
   */
  public static DBCatalog getDB() {
    return db;
  }

  /**
   * Sets the database catalog by storing the db directory and creating the schema.
   *
   * @param directory - the input directory.
   */
  public void setDBCatalog(String directory, String tempDir) {
    dbDirectory = directory + "/db";
    tempDirectory = tempDir;
    indexDir = dbDirectory + "/indexes/";
    createSchema();
    setAllTableStats();
    setIndexMeta();
  }

  /** Sets the schema in the database catalog. */
  private void createSchema() {
    try {
      String line;
      BufferedReader br = new BufferedReader(new FileReader(dbDirectory + "/schema.txt"));

      while ((line = br.readLine()) != null) {
        ArrayList<Column> columns = new ArrayList<Column>();
        String[] tokens = line.split("\\s");
        String tableName = tokens[0];

        for (int i = 1; i < tokens.length; i++) {
          columns.add(new Column(new Table(null, tableName), tokens[i]));
        }
        tables.put(tableName, columns);
      }
      br.close();
    } catch (Exception e) {
      logger.error(e.getMessage());
    }
  }

  private void setAllTableStats() {
    for (String tableName : DBCatalog.getDB().getAllTables().keySet()) {
      TableStats stats = new TableStats(tableName);
      StatsWriter statsWriter = new StatsWriter();
      allTableStats.put(tableName, stats);
      statsWriter.writeTableStatsToFile(stats);
    }
  }

  /**
   * Reads index information from the "index_info.txt" file in the specified database directory.
   * Parses each line of the file to extract table name, column name, clustering status, and order.
   * Retrieves corresponding columns from the database schema and creates Index objects. Populates
   * the 'indexes' map with table names as keys and Index objects as values.
   */
  public void setIndexMeta() {
    try {
      String line = null;
      BufferedReader br = new BufferedReader(new FileReader(dbDirectory + "/index_info.txt"));

      while ((line = br.readLine()) != null) {
        String[] info = line.split(" ");
        String tableName = info[0];
        String columnName = info[1];
        boolean isClustered = Integer.parseInt(info[2]) != 0;
        int order = Integer.valueOf(info[3]);
        Column indexColumn = getColumnFromSchema(tableName, columnName);
        String indexPath = indexDir + tableName + "." + columnName;
        if (indexes.containsKey(tableName)) {
          indexes.get(tableName).add(new Index(indexPath, order, indexColumn, isClustered));
        } else {
          ArrayList<Index> tableIndexes = new ArrayList<Index>();
          tableIndexes.add(new Index(indexPath, order, indexColumn, isClustered));
          indexes.put(tableName, tableIndexes);
        }
      }

      br.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public String getDBDirectory() {
    return dbDirectory;
  }

  /**
   * Returns the path where temporary scratch files required for external sorting will be stored.
   *
   * @return path to temp directory.
   */
  public String getTempDirectory() {
    return tempDirectory;
  }

  /**
   * Returns all table metadata stored in the Catalog
   *
   * @return a mapping of table name and schema
   */
  public HashMap<String, ArrayList<Column>> getAllTables() {
    return tables;
  }

  public HashMap<String, TableStats> getAllTableStats() {
    return allTableStats;
  }

  /**
   * Returns a HashMap containing table names as keys and corresponding Index objects as values. The
   * HashMap represents the indexes stored in the system.
   *
   * @return HashMap<String, Index> A mapping of table names to Index objects.
   */
  public HashMap<String, ArrayList<Index>> getIndexMapping() {
    return indexes;
  }

  public ArrayList<Index> getAllIndexes() {
    ArrayList<Index> allIndexes = new ArrayList<>();
    for (ArrayList<Index> tableIndexes : indexes.values()) {
      allIndexes.addAll(tableIndexes);
    }

    return allIndexes;
  }

  /**
   * Returns columns for the given table
   *
   * @param tableName - name of the table
   * @return list of columns for the given table
   */
  public ArrayList<Column> getTableColumns(String tableName) {
    return tables.get(tableName);
  }

  public Column getColumnFromSchema(String tableName, String columnName) {
    ArrayList<Column> columns = tables.get(tableName);
    for (Column col : columns) {
      if (col.getColumnName().equals(columnName)) return col;
    }
    return null;
  }

  /**
   * Gets path to file where a particular table is stored
   *
   * @param tableName - name of the table
   * @return file where table is found on disk
   */
  public File getFileForTable(String tableName) {
    return new File(dbDirectory + "/data/" + tableName);
  }
}
