package common;

public class Record {
  // PageId is the number of the page the tuple is on
  // TupleId is the number of the tuple on the page numbered pageId
  private int pageId;
  private int tupleId;

  /**
   * Constructs a Record object with the specified page number and tuple number.
   *
   * @param pageNum The page number where the tuple is located.
   * @param tupleNum The tuple number within the specified page.
   */
  public Record(int pageNum, int tupleNum) {
    pageId = pageNum;
    tupleId = tupleNum;
  }

  /**
   * Gets the page number where the tuple is located.
   *
   * @return int The page number of the record.
   */
  public int getPageId() {
    return pageId;
  }

  /**
   * Gets the tuple number within the specified page.
   *
   * @return int The tuple number of the record.
   */
  public int getTupleId() {
    return tupleId;
  }

  /**
   * Returns a string representation of the Record object in the format "(pageId, tupleId)".
   *
   * @return String The string representation of the Record object.
   */
  public String toString() {
    return "(" + pageId + "," + tupleId + ")";
  }
}
