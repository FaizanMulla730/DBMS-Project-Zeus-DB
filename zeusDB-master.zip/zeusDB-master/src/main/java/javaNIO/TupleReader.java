package javaNIO;

import common.Tuple;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import util.Constants;

/** A class for reading tuples from a binary file using NIO (New I/O) channels and buffers. */
public class TupleReader {
  private File file;
  private FileInputStream fin;
  private FileChannel fc;
  private ByteBuffer buffer;
  private Integer tupleSize;
  private Integer numTuples;
  private Integer numReadTuple;
  // reachedEOF is only used for the readPage function, in readTuple it is not required.
  private Boolean reachedEOF;

  /**
   * Constructs a TupleReader object to read tuples from the specified input file.
   *
   * @param inputFile The input file to read tuples from.
   */
  public TupleReader(File inputFile) {
    this.file = inputFile;
    this.reachedEOF = false;
    initFileHandlers();
    setMetadata();
  }

  private void initFileHandlers() {
    try {
      this.fin = new FileInputStream(file);
      this.fc = fin.getChannel();
      this.buffer = ByteBuffer.allocate(Constants.IO.PAGE_SIZE);
      this.buffer.clear();
      this.fc.read(buffer);
      this.buffer.flip();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Sets the metadata (tuple size and number of tuples) based on the current state of the buffer.
   * If there are remaining elements in the buffer, it reads the tuple size and number of tuples
   * from the buffer and updates the internal metadata variables accordingly. If the buffer is
   * empty, it sets both tuple size and number of tuples to 0. Resets the count of read tuples to 0.
   */
  public void setMetadata() {
    if (buffer.hasRemaining()) {
      tupleSize = buffer.getInt();
      numTuples = buffer.getInt();
    } else {
      tupleSize = 0;
      numTuples = 0;
    }
    numReadTuple = 0;
  }

  /**
   * Reads a single tuple from the input file.
   *
   * @return A Tuple object containing the values read from the file, or null if the end of the file
   *     is reached.
   */
  public Tuple readTuple() {
    try {
      ArrayList<Integer> tupleList = new ArrayList<Integer>();
      while (true) {
        if (numTuples == 0) return null;
        else if (numReadTuple.equals(numTuples)) {
          buffer.clear();
          int readIndex = fc.read(buffer);
          if (readIndex <= 0) return null;
          buffer.flip();
          setMetadata();
        }
        for (int i = 0; i < tupleSize; i++) {
          tupleList.add(buffer.getInt());
        }
        numReadTuple = numReadTuple + 1;
        return new Tuple(tupleList);
      }
    } catch (IOException e) {
      e.printStackTrace();
      return null;
    }
  }

  /**
   * Reads and retrieves all the tuples on the current page of the input file
   *
   * @return ArrayList<Tuple> An ArrayList containing Tuple objects read from the page.
   */
  public ArrayList<Tuple> readPage() {
    try {
      ArrayList<Tuple> tuples = new ArrayList<Tuple>();
      while (true) {
        if (numTuples == 0) return null;
        if (reachedEOF) return null;
        for (int i = 0; i < numTuples; i++) {
          ArrayList<Integer> tupleList = new ArrayList<Integer>();
          for (int j = 0; j < tupleSize; j++) {
            tupleList.add(buffer.getInt());
          }
          tuples.add(new Tuple(tupleList));
          numReadTuple++;
        }
        buffer.clear();
        int readIndex = fc.read(buffer);
        if (readIndex <= 0) reachedEOF = true;
        buffer.flip();
        setMetadata();
        return tuples;
      }
    } catch (IOException e) {
      e.printStackTrace();
      return null;
    }
  }

  /** Closes the file channel and input stream, releasing associated resources. */
  public void close() {
    try {
      buffer.clear();
      fc.close();
      fin.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Resets the TupleReader to the beginning of the input file. Closes the current file channel and
   * input stream, then reopens the file and resets the internal state.
   */
  public void reset() {
    close();
    try {
      fin = new FileInputStream(file);
      fc = fin.getChannel();
      buffer.clear();
      fc.read(buffer);
      buffer.flip();
      setMetadata();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Resets the position of the tupleReader to given index. It jumps directly to the required page
   * using FileChannel and then reads data into the buffer.
   *
   * @param newPosition the new position to set for the tupleReader.
   */
  public void reset(int newPosition) {
    try {
      close();
      fin = new FileInputStream(file);
      fc = fin.getChannel();
      // Reset the position of the FileChannel:
      fc.position(newPosition);
      buffer.clear();
      fc.read(buffer);
      buffer.flip();
      setMetadata();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
