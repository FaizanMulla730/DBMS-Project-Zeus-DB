package javaNIO;

import common.Tuple;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import util.Constants;

/** A class for writing tuples to a binary file using NIO (New I/O) channels and buffers. */
public class TupleWriter {
  private FileOutputStream fout;
  private FileChannel fc;
  private ByteBuffer buffer;
  private Integer tupleSize;
  private Integer numTuples;

  /**
   * Constructs a TupleWriter object to write tuples to the specified file.
   *
   * @param file The file to write tuples to.
   */
  public TupleWriter(File file) {
    initFileHandlers(file);
    this.tupleSize = 0;
    this.numTuples = 0;
  }

  private void initFileHandlers(File file) {
    try {
      this.fout = new FileOutputStream(file);
      this.fc = fout.getChannel();
      this.buffer = ByteBuffer.allocate(Constants.IO.PAGE_SIZE);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Moves the buffer to the next page, writing the final count of processed tuples and resetting
   * internal counters for tuple size and number of tuples.
   */
  public void moveToNextPage() {
    try {
      // Pad remaining empty spaces with 0s
      while (buffer.hasRemaining()) {
        buffer.putInt(0);
      }
      // Write the final count of processed tuples
      buffer.putInt(4, numTuples);
      buffer.flip();
      fc.write(buffer);
      buffer.clear();
      tupleSize = 0;
      numTuples = 0;
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Writes a tuple to the file. If the current page is full, it moves to the next page and
   * continues writing.
   *
   * @param t The Tuple object to be written to the file.
   */
  public void writeTuple(Tuple t) {
    // Check if the current tuple can fit on current page. If not fill the current page with zeros
    // and create a new page
    if ((buffer.limit() - buffer.position()) < (tupleSize * Constants.IO.INT_SIZE)) {
      moveToNextPage();
    }
    // If this is first tuple on page, fill in first two entries with size and number of tuples on
    // page
    if (buffer.position() == 0) {
      tupleSize = t.getAllElements().size();
      buffer.putInt(tupleSize);
      buffer.putInt(numTuples);
    }

    for (int i = 0; i < tupleSize; i++) {
      buffer.putInt(t.getElementAtIndex(i));
    }
    numTuples = numTuples + 1;
  }

  /**
   * Closes the file channel and output stream, releasing associated resources. If there are
   * processed tuples, it pads the remaining empty spaces with zeros, writes the final count of
   * processed tuples, and then closes the file channel and output stream. If there are no processed
   * tuples, it simply closes the file channel and output stream.
   */
  public void close() {
    try {
      if (numTuples > 0) {
        // Pad remaining empty spaces with 0s
        while (buffer.hasRemaining()) {
          buffer.putInt(0);
        }
        buffer.putInt(4, numTuples);
      }
      buffer.flip();
      fc.write(buffer);
      buffer.clear();
      fc.close();
      fout.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
