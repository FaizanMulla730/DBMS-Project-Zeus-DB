package javaNIO;

import common.Tuple;
import java.io.*;

/** Class to convert data from binary files into human readable format text file. */
public class Converter {
  private TupleReader tReader;
  private String outputFilePath;
  private FileOutputStream outputStream;

  public Converter(File inputFile) {
    tReader = new TupleReader(inputFile);
    outputFilePath = inputFile.getPath().concat("_humanreadbile.txt");
  }

  /**
   * Reads binary data using the tupleReader from the input file, converts it to a human-readable
   * format, and saves the result in a new text file.
   */
  public void convert() {
    try {
      outputStream = new FileOutputStream(outputFilePath);

      Tuple t;
      while ((t = tReader.readTuple()) != null) {
        outputStream.write(t.toString().getBytes());
        outputStream.write('\n');
      }

      outputStream.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
