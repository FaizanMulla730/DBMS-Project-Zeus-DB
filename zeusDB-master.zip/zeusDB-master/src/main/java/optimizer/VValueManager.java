package optimizer;

import java.util.HashMap;
import java.util.Map;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;

public class VValueManager {
  private Map<String, VValues> vValuesMap;

  public VValueManager() {
    vValuesMap = new HashMap<>();
  }

  public void addTableVValues(
      String tableName, Column column, Integer lowerBound, Integer upperBound) {
    VValues values = new VValues(tableName);
    values.addVValue(column, lowerBound, upperBound);
    vValuesMap.put(tableName, values);
  }

  public int getTableVValue(String tableName) {
    return vValuesMap.get(tableName).getMinimumVValue();
  }

  public int getTableVValue(Table table) {
    return vValuesMap.get(table.getName()).getMinimumVValue();
  }
}
