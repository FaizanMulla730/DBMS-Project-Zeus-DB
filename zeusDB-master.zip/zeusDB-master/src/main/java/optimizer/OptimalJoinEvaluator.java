package optimizer;

import java.util.*;
import net.sf.jsqlparser.schema.Table;

public class OptimalJoinEvaluator {
  private ArrayList<Table> tables;
  private VValueManager vValueManager;
  private HashMap<List<Table>, Double> planCosts;

  public OptimalJoinEvaluator(ArrayList<Table> tables, VValueManager vValueManager) {
    this.tables = tables;
    this.vValueManager = vValueManager;
    this.planCosts = new HashMap<>();
    setOptimalJoinOrder(this.tables);
  }

  public double setOptimalJoinOrder(List<Table> subTables) {

    // Base condition
    if (subTables.size() == 0) {
      return 1.0;
    }

    // Directly return instead of calc the sub values
    // No need to calculate the subvalues again and again
    if (planCosts.containsKey(subTables)) {
      return planCosts.get(subTables);
    }

    if (subTables.size() == 1) {
      double value = vValueManager.getTableVValue(subTables.get(0));
      planCosts.put(subTables, value);
      return value;
    }

    if (subTables.size() == 2) {
      double value =
          vValueManager.getTableVValue(subTables.get(0))
              * vValueManager.getTableVValue(subTables.get(1));
      planCosts.put(subTables, value);
      return value;
    }

    // recussively generate the plans
    double value = 1;
    for (int i = 0; i < subTables.size(); i++) {
      List<Table> left = subTables.subList(0, i);
      List<Table> right = subTables.subList(i + 1, subTables.size());
      List<Table> outerRelation = new ArrayList<>();
      outerRelation.add(subTables.get(i));
      value =
          setOptimalJoinOrder(outerRelation)
              * (setOptimalJoinOrder(left) + setOptimalJoinOrder(right));
      outerRelation.addAll(left);
      outerRelation.addAll(right);
      if (outerRelation.size() > tables.size()) break;
      planCosts.put(outerRelation, value);
    }

    return value;
  }

  public List<Table> getOptimalJoinOrder() {
    List<Table> optimalJoinOrder = new ArrayList<>();

    double optimalCost = Double.MAX_VALUE;
    for (List<Table> plan : planCosts.keySet()) {
      if (planCosts.get(plan) <= optimalCost && plan.size() == tables.size()) {
        optimalJoinOrder = plan;
        optimalCost = planCosts.get(plan);
      }
    }

    return optimalJoinOrder;
  }
}
