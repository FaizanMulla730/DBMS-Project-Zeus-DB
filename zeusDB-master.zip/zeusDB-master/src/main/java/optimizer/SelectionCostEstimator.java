package optimizer;

import btree.BTreeDeserializer;
import common.DBCatalog;
import common.Index;
import common.TableStats;
import java.util.ArrayList;
import net.sf.jsqlparser.schema.Column;
import util.Constants;

public class SelectionCostEstimator {
  private Integer indexResultNumTuples;

  public SelectionCostEstimator() {}

  public Integer getIndexResultNumTuples() {
    return indexResultNumTuples;
  }

  public Integer calculateScanCost(ArrayList<Column> outputSchema) {
    String tableName = outputSchema.get(0).getTable().getName();
    TableStats stats = DBCatalog.getDB().getAllTableStats().get(tableName);
    Integer numTuples = stats.getSize();
    Integer tupleSize = stats.getColumnStats().size() * Constants.IO.INT_SIZE;

    return Math.ceilDiv((numTuples * tupleSize), Constants.IO.PAGE_SIZE);
  }

  public Integer calculateScanCostAfterIndex(
      ArrayList<Column> outputSchema, Integer childResultSize) {
    String tableName = outputSchema.get(0).getTable().getName();
    TableStats stats = DBCatalog.getDB().getAllTableStats().get(tableName);
    Integer tupleSize = stats.getColumnStats().size() * Constants.IO.INT_SIZE;

    return Math.ceilDiv((childResultSize * tupleSize), Constants.IO.PAGE_SIZE);
  }

  public Integer calculateIndexScanCost(
      ArrayList<Column> outputSchema, Index index, Integer lowKey, Integer highKey) {
    String tableName = outputSchema.get(0).getTable().getName();
    TableStats stats = DBCatalog.getDB().getAllTableStats().get(tableName);
    Column indexColumn = index.getIndexColumn();
    Integer totalRange =
        stats.getColumnStats().get(indexColumn)[1] - stats.getColumnStats().get(indexColumn)[0];
    double reductionFactor = (highKey - lowKey) / totalRange;
    Integer numTuples = stats.getSize();
    Integer tupleSize = stats.getColumnStats().size() * Constants.IO.INT_SIZE;
    Integer numPages = Math.ceilDiv((numTuples * tupleSize), Constants.IO.PAGE_SIZE);

    indexResultNumTuples = (int) Math.round(Math.ceil(numTuples * reductionFactor));
    if (index.isClustered()) {
      return (int) Math.round(Math.ceil(3 + (numPages * reductionFactor)));
    } else {
      BTreeDeserializer td = new BTreeDeserializer(index);
      Integer numLeaves = td.getNumLeaves();
      td.close();
      return (int)
          Math.round(Math.ceil(3 + (numLeaves * reductionFactor) + (numTuples * reductionFactor)));
    }
  }
}
