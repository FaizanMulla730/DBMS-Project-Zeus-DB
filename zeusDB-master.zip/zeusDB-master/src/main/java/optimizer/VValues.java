package optimizer;

import common.*;
import java.util.*;
import net.sf.jsqlparser.schema.Column;

public class VValues {
  private Map<String, Integer> vValues;
  private TableStats tableStats;

  public VValues(String tableName) {
    this.vValues = new HashMap<>();
    this.tableStats = DBCatalog.getDB().getAllTableStats().get(tableName);
  }

  private void updateAllVValues(String columnName, int value) {
    if (vValues.size() > 0) {
      if (!vValues.containsKey(columnName)) {
        vValues.put(columnName, value);
      }

      for (String colName : vValues.keySet()) {
        if (vValues.get(colName) > value) {
          vValues.put(colName, value);
        }
      }
    } else {
      vValues.put(columnName, value);
    }
  }

  public void addVValue(Column column, Integer lowerBound, Integer upperBound) {
    HashMap<Column, Integer[]> columnStats = tableStats.getColumnStats();
    Integer[] bounds = columnStats.get(column);
    int range = bounds[1] - bounds[0] + 1;

    int calculatedVVal = 1;
    if (lowerBound != null && upperBound != null) {
      if (lowerBound.equals(upperBound)) {
        calculatedVVal = 1;
      }
      calculatedVVal = Math.ceilDiv(upperBound - lowerBound, range);
    } else if (lowerBound != null && upperBound == null) {
      calculatedVVal = Math.ceilDiv(bounds[1] - lowerBound, range);
    } else if (lowerBound == null && upperBound != null) {
      calculatedVVal = Math.ceilDiv(upperBound - bounds[0], range);
    } else {
      calculatedVVal = range;
    }
    updateAllVValues(column.getColumnName(), calculatedVVal);
  }

  public int getMinimumVValue() {
    return vValues.entrySet().stream()
        .min(Comparator.comparingInt(Map.Entry::getValue))
        .orElse(null)
        .getValue();
  }
}
