package logical;

import builder.PhysicalPlanBuilder;
import java.util.ArrayList;
import java.util.List;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.SelectExpressionItem;
import net.sf.jsqlparser.statement.select.SelectItem;

/** LogicalProject is the logical representation of a physical ProjectOperator */
public class LogicalProject extends LogicalOperator {
  private List<SelectItem> columns;
  private LogicalOperator child;

  /**
   * Constructs a LogicalProject operator
   *
   * @param outputSchema the table from which the physical operator will draw data
   * @param child the child of this operator in the query plan tree
   * @param selectItems the column(s) found in the select clause of the query
   */
  public LogicalProject(
      ArrayList<Column> outputSchema, LogicalOperator child, List<SelectItem> selectItems) {
    super(outputSchema);
    this.child = child;
    this.columns = selectItems;
  }

  /**
   * Returns columns that should be kept after projection
   *
   * @return list of desired column names (as list of SelectItems)
   */
  public List<SelectItem> getColumns() {
    return columns;
  }

  /**
   * Returns child of this operator in query plan tree
   *
   * @return child of this operator in query plan tree
   */
  public LogicalOperator getChild() {
    return child;
  }

  /**
   * Returns columns that should be kept after project (as ArrayList of columns)
   *
   * @return ArrayList of projected columns
   */
  public ArrayList<Column> getSelectColumns() {
    ArrayList<Column> selectColumns = new ArrayList<>();
    for (SelectItem selectItem : columns) {
      if (selectItem instanceof SelectExpressionItem) {
        SelectExpressionItem expressionItem = (SelectExpressionItem) selectItem;
        Column column = (Column) expressionItem.getExpression();
        selectColumns.add(column);
      }
    }
    return selectColumns;
  }

  /**
   * Accepts the PhysicalPlanBuilder to convert from logical to physical operator
   *
   * @param pb the PhysicalPlanBuilder being used to convert query plan
   */
  public void accept(PhysicalPlanBuilder pb) {
    pb.visit(this);
  }

  public String print(int level) {
    String[] columnStrs = new String[columns.size()];
    for (int i = 0; i < columns.size(); i++) {
      columnStrs[i] = columns.get(i).toString();
    }
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("Project");
    sb.append("[" + String.join(", ", columnStrs) + "]");
    sb.append("\n");
    sb.append(child.print(++level));
    return sb.toString();
  }
}
