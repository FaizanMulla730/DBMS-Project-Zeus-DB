package logical;

import builder.PhysicalPlanBuilder;
import java.util.ArrayList;
import net.sf.jsqlparser.schema.Column;

/** LogicalJoin is the logical representation of a join operation for a logical query plan */
public class LogicalCrossJoin extends LogicalOperator {
  private LogicalOperator leftChild;
  private LogicalOperator rightChild;

  /**
   * Constructs a LogicalJoin operator.
   *
   * @param outputSchema table from which the physical JoinOperator will draw data from
   * @param leftChild left child of LogicalJoin in the query plan tree
   * @param rightChild right child of LogicalJoin in the query plan tree
   * @param join the join expression for this join operation
   */
  public LogicalCrossJoin(
      ArrayList<Column> outputSchema, LogicalOperator leftChild, LogicalOperator rightChild) {
    super(outputSchema);
    this.leftChild = leftChild;
    this.rightChild = rightChild;
  }

  /** Returns left child of this operator */
  public LogicalOperator getLeftChild() {
    return leftChild;
  }

  /** Returns right child of this operator */
  public LogicalOperator getRightChild() {
    return rightChild;
  }

  /** Visits the LogicalJoin operator for conversion to physical operator */
  public void accept(PhysicalPlanBuilder pb) {
    pb.visit(this);
  }

  public String print(int level) {
    String leftTableName = leftChild.getSchema().get(0).getTable().getName();
    String rightTableName = rightChild.getSchema().get(0).getTable().getName();

    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("Join");
    sb.append("[" + leftTableName + ", " + rightTableName + "]");
    sb.append("\n");
    sb.append(leftChild.print(++level));
    sb.append(rightChild.print(++level));
    return sb.toString();
  }
}
