package logical;

import builder.PhysicalPlanBuilder;
import java.util.ArrayList;
import net.sf.jsqlparser.schema.Column;

/**
 * LogicalDistinct is the logical representation of a DuplicateEliminationOperator for a logical
 * query plan tree.
 */
public class LogicalDistinct extends LogicalOperator {
  private LogicalOperator child;

  /**
   * Constructs a LogicalDistinct operator.
   *
   * @param outputSchema table from which physical operator will retrieve data
   * @param child childOperator of the LogicalDistinct operator
   */
  public LogicalDistinct(ArrayList<Column> outputSchema, LogicalOperator child) {
    super(outputSchema);
    this.child = child;
  }

  /** Returns the child of this LogicalDistinct operator */
  public LogicalOperator getChild() {
    return child;
  }

  /** Visits the LogicalDistinct operator for conversion to physical operator */
  public void accept(PhysicalPlanBuilder pb) {
    pb.visit(this);
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("DupElim");
    sb.append("\n");
    sb.append(child.print(++level));
    return sb.toString();
  }
}
