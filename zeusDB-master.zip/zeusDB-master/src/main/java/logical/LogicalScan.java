package logical;

import builder.PhysicalPlanBuilder;
import java.util.ArrayList;
import net.sf.jsqlparser.schema.Column;

/**
 * LogicalScan is the logical representation of a physical ScanOperator for a logical query plan
 * tree.
 */
public class LogicalScan extends LogicalOperator {

  /**
   * Constructs a LogicalScan operator
   *
   * @param outputSchema the table from which the physical ScanOperator will draw data
   */
  public LogicalScan(ArrayList<Column> outputSchema) {
    super(outputSchema);
  }

  /**
   * Accepts the PhysicalPlanBuilder to convert to physical operator
   *
   * @param pb the PhysicalPlanBuilder being used to convert from logical to physical query plan
   */
  public void accept(PhysicalPlanBuilder pb) {
    pb.visit(this);
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("Leaf");
    sb.append("[" + outputSchema.get(0).getTable().getName() + "]");
    sb.append("\n");
    return sb.toString();
  }
}
