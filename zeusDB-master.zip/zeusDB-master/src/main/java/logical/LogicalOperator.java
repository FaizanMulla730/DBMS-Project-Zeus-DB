package logical;

import builder.PhysicalPlanBuilder;
import java.util.ArrayList;
import net.sf.jsqlparser.schema.Column;

/**
 * LogicalOperator is the superclass representing the types of operators in a logical query plan
 * tree.
 */
public abstract class LogicalOperator {
  protected ArrayList<Column> outputSchema;

  /**
   * Constructs a LogicalOperator.
   *
   * @param outputSchema the table from which the LogicalOperator draws data
   */
  public LogicalOperator(ArrayList<Column> outputSchema) {
    this.outputSchema = outputSchema;
  }

  /** Returns the schema of this LogicalOperator */
  public ArrayList<Column> getSchema() {
    return outputSchema;
  }

  /**
   * Get index of the given column from its table's column array.
   *
   * <p>Note: The table's column array is stored in the schema.
   *
   * @param column - column for which index is required
   * @return index of the given column in the table's column array.
   */
  public int getColumnNumberFromSchema(Column column) {
    for (Column schemaColumn : outputSchema) {
      if (column.getColumnName().equals(schemaColumn.getColumnName())
          && column.getTable().getName().equals(schemaColumn.getTable().getName())) {
        return outputSchema.indexOf(schemaColumn);
      }
    }
    return -1;
  }

  /**
   * Visit operator for conversion to physical operator
   *
   * @param pb the PhysicalPlanBuilder visitor to convert logical plan to physical plan
   */
  public abstract void accept(PhysicalPlanBuilder pb);

  public abstract String print(int level);
}
