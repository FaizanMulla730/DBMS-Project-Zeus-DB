package logical;

import builder.PhysicalPlanBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import optimizer.OptimalJoinEvaluator;
import optimizer.VValueManager;
import union_find.UnionFind;

public class LogicalMultiJoin extends LogicalOperator {
  private ArrayList<Table> children;
  private UnionFind unionFind;
  private ArrayList<Expression> residualExpressions;
  private HashMap<String, LogicalOperator> logicalSelections;
  private HashMap<String, ArrayList<Expression>> joinConditions;
  private VValueManager vValueManager;
  private List<Table> optimalJoinOrder;

  public LogicalMultiJoin(
      ArrayList<Column> combinedSchema,
      ArrayList<Table> children,
      HashMap<String, ArrayList<Expression>> joinConditions,
      UnionFind unionFind,
      ArrayList<Expression> residualExpressions,
      HashMap<String, LogicalOperator> logicalSelections,
      VValueManager vValueManager) {
    super(combinedSchema);
    this.children = children;
    this.unionFind = unionFind;
    this.residualExpressions = residualExpressions;
    this.logicalSelections = logicalSelections;
    this.joinConditions = joinConditions;
    this.vValueManager = vValueManager;
    setOptimalJoinOrder();
  }

  public void setOptimalJoinOrder() {
    OptimalJoinEvaluator opJoinEval = new OptimalJoinEvaluator(children, vValueManager);
    optimalJoinOrder = opJoinEval.getOptimalJoinOrder();
  }

  public ArrayList<Table> getChildren() {
    return children;
  }

  public UnionFind getUnionFind() {
    return unionFind;
  }

  public ArrayList<Expression> getResidualExpressions() {
    return residualExpressions;
  }

  public HashMap<String, LogicalOperator> getLogicalSelections() {
    return logicalSelections;
  }

  public HashMap<String, ArrayList<Expression>> getJoinConditions() {
    return joinConditions;
  }

  public VValueManager getVValueManager() {
    return vValueManager;
  }

  public List<Table> getOptimalJoinOrder() {
    return optimalJoinOrder;
  }

  @Override
  public void accept(PhysicalPlanBuilder pb) {
    pb.visit(this);
  }

  public String print(int level) {
    String[] residualExpStrs = new String[residualExpressions.size()];
    for (int i = 0; i < residualExpressions.size(); i++) {
      residualExpStrs[i] = residualExpressions.get(i).toString();
    }
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("Join");
    sb.append("[" + String.join(" AND ", residualExpStrs) + "]");
    sb.append("\n");
    sb.append(unionFind.print());
    ++level;
    for (LogicalOperator child : logicalSelections.values()) {
      sb.append(child.print(level));
    }
    return sb.toString();
  }
}
