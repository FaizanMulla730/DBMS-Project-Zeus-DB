package logical;

import builder.PhysicalPlanBuilder;
import java.util.ArrayList;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Column;

/** LogicalSelect is the logical representation of a physical SelectOperator */
public class LogicalSelect extends LogicalOperator {
  private Expression selectCondition;
  private LogicalOperator child;

  /**
   * Constructs a LogicalSelect operator.
   *
   * @param outputSchema the table from which the physical SelectOperator will draw data
   * @param child the child of this operator in the logical query plan tree
   * @param exp the select condition on the table in output schema
   */
  public LogicalSelect(ArrayList<Column> outputSchema, LogicalOperator child, Expression exp) {
    super(outputSchema);
    this.child = child;
    this.selectCondition = exp;
  }

  /**
   * Returns the select condition for this operator
   *
   * @return select condition of this operator
   */
  public Expression getSelectCondition() {
    return selectCondition;
  }

  /**
   * Returns the child of this operator
   *
   * @return child of this operator
   */
  public LogicalOperator getChild() {
    return child;
  }

  /**
   * Accepts the PhysicalPlanBuilder being used to convert from logical to physical query plan
   *
   * @param pb the PhysicalPlanBuilder for converting from logical to physical plan
   */
  public void accept(PhysicalPlanBuilder pb) {
    pb.visit(this);
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("Select");
    sb.append("[" + selectCondition.toString() + "]");
    sb.append("\n");
    sb.append(child.print(++level));
    return sb.toString();
  }
}
