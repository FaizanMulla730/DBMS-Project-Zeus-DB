package logical;

import builder.PhysicalPlanBuilder;
import java.util.ArrayList;
import java.util.List;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.OrderByElement;

/**
 * LogicalSort is the logical representation of a physical SortOperator in a logical query plan tree
 */
public class LogicalSort extends LogicalOperator {
  private LogicalOperator child;
  private List<OrderByElement> orderConditions;

  /**
   * Constructs a LogicalSort operator
   *
   * @param outputSchema the table from which the physical operator will draw data
   * @param child the child of this operator in the query plan tree
   * @param orderBy list of the columns in the OrderBy clause
   */
  public LogicalSort(
      ArrayList<Column> outputSchema, LogicalOperator child, List<OrderByElement> orderBy) {
    super(outputSchema);
    this.child = child;
    this.orderConditions = orderBy;
  }

  /**
   * Returns the child of this operator
   *
   * @return child of this operator
   */
  public LogicalOperator getChild() {
    return child;
  }

  /**
   * Returns a list of columns in the OrderBy clause
   *
   * @return list of columns to order by
   */
  public List<OrderByElement> getOrderConditions() {
    return orderConditions;
  }

  /**
   * Accepts the PhysicalPlanBuilder being used to convert from logical to physical query plan
   *
   * @param pb the PhysicalPlanBuilder for converting from logical to physical plan
   */
  public void accept(PhysicalPlanBuilder pb) {
    pb.visit(this);
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    if (orderConditions != null) {
      String[] orderByStrs = new String[orderConditions.size()];
      for (int i = 0; i < orderConditions.size(); i++) {
        orderByStrs[i] = orderConditions.get(i).toString();
      }
      sb.append("-".repeat(level));
      sb.append("Sort");
      sb.append("[" + String.join(", ", orderByStrs) + "]");
      sb.append("\n");
      ++level;
    }
    sb.append(child.print(level));
    return sb.toString();
  }
}
