package visitor;

import common.TableStats;
import java.util.ArrayList;
import net.sf.jsqlparser.expression.BinaryExpression;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.conditional.OrExpression;
import net.sf.jsqlparser.expression.operators.relational.*;
import net.sf.jsqlparser.schema.Column;

/**
 * IndexVisitor parses the select condition from the logical select operator if the table in the
 * logical select operator has an index, extracts the index applicable conditions to create the
 * interval [lowkey, highkey] for IndexScan, and retains the remainder of the select condition if
 * there is one.
 */
public class IndexVisitor extends ConditionVisitor {
  private Boolean useIndex;
  private Boolean isIndexColumn;
  private Integer lowerBound;
  private Integer upperBound;
  private Column indexColumn;
  private ArrayList<Expression> selectConditions;
  private ArrayList<String> conditionTypes;

  /**
   * Constructs an IndexVisitor
   *
   * @param indexColumn the column on which the table in the LogicalSelect operator is indexed
   */
  public IndexVisitor(Column indexColumn) {
    TableStats stats = new TableStats(indexColumn.getTable().getName());
    this.useIndex = false;
    this.lowerBound = stats.getColumnStats().get(indexColumn)[0];
    this.upperBound = stats.getColumnStats().get(indexColumn)[1];
    this.indexColumn = indexColumn;
    this.selectConditions = new ArrayList<Expression>();
    this.conditionTypes = new ArrayList<String>();
  }

  /**
   * Return whether index usable conditions were found in the select condition
   *
   * @return useIndex
   */
  public boolean useIndex() {
    return useIndex;
  }

  /**
   * Return lower bound for index scan
   *
   * @return the integer lower bound
   */
  public Integer getLowerBound() {
    return lowerBound;
  }

  /**
   * Return upper bound for index scan
   *
   * @return the integer upper bound
   */
  public Integer getUpperBound() {
    return upperBound;
  }

  /** Resets class variables checking whether visited expression was/contained an index column. */
  public void resetColumnBooleans() {
    isIndexColumn = false;
  }

  /**
   * Returns array of non-index usable select conditions
   *
   * @return the array of select conditions
   */
  public ArrayList<Expression> getSelectConditions() {
    return selectConditions;
  }

  /**
   * Visits a ComparisonOperator (the superclass for GreaterThan, EqualTo, etc.), checks whether the
   * index column is contained in the expression, and if so, sets the upper and or lower bound
   * appropriately.
   */
  private void visitExpression(ComparisonOperator e) {
    Expression left = e.getLeftExpression();
    Expression right = e.getRightExpression();
    Integer currentValue;

    resetColumnBooleans();
    left.accept(this);
    if (isIndexColumn) {
      useIndex = true;
      right.accept(this);
      currentValue = getLongValue().intValue();

      setBounds(currentValue, e);
    } else {
      right.accept(this);
      if (isIndexColumn) {
        useIndex = true;
        currentValue = getLongValue().intValue();

        setBounds(currentValue, e);
      } else {
        selectConditions.add(e);
      }
    }
  }

  /**
   * Sets lower and or upperBound according to the integer value from the visited expression and the
   * type of comparison relation.
   */
  private void setBounds(Integer currentValue, ComparisonOperator e) {
    if (e instanceof EqualsTo) {
      lowerBound = currentValue;
      upperBound = currentValue;
    } else {
      if (lowerBound.compareTo(currentValue) > 0 || lowerBound.equals(lowerBound)) {
        if (e instanceof GreaterThanEquals) {
          lowerBound = currentValue;
        } else if (e instanceof GreaterThan) {
          lowerBound = currentValue + 1;
        }
      }

      if (upperBound.compareTo(currentValue) < 0 || upperBound.equals(upperBound)) {
        if (e instanceof MinorThanEquals) {
          upperBound = currentValue;
        } else if (e instanceof MinorThan) {
          upperBound = currentValue - 1;
        }
      }
    }
  }

  /** Determines whether the visited column is the indexed column */
  @Override
  public void visit(Column c) {
    if (c.getFullyQualifiedName().equals(indexColumn.getFullyQualifiedName())) {
      isIndexColumn = true;
    }
  }

  /**
   * Visits an EqualsTo expression.
   *
   * @param equalsTo the expression to visit
   */
  @Override
  public void visit(EqualsTo equalsTo) {
    visitExpression(equalsTo);
  }

  /**
   * Visit NotEqualsTo expression.
   *
   * @param notEqualsTo the expression to visit
   */
  @Override
  public void visit(NotEqualsTo notEqualsTo) {
    selectConditions.add(notEqualsTo);
    resetColumnBooleans();
  }

  /**
   * Visit GreaterThan expression.
   *
   * @param greaterThan the expression to visit
   */
  @Override
  public void visit(GreaterThan greaterThan) {
    visitExpression(greaterThan);
  }

  /**
   * Visit GreaterThanEquals expression.
   *
   * @param greaterThanEquals the expression to visit
   */
  @Override
  public void visit(GreaterThanEquals greaterThanEquals) {
    visitExpression(greaterThanEquals);
  }

  /**
   * Visit MinorThan expression.
   *
   * @param minorThan the expression to visit
   */
  @Override
  public void visit(MinorThan minorThan) {
    visitExpression(minorThan);
  }

  /**
   * Visit MinorThanEquals expression.
   *
   * @param minorThanEquals the expression to visit
   */
  @Override
  public void visit(MinorThanEquals minorThanEquals) {
    visitExpression(minorThanEquals);
  }

  /**
   * Visit an AndExpression expression.
   *
   * @param andExpression the expression to visit
   */
  @Override
  public void visit(AndExpression andExpression) {
    andExpression.getLeftExpression().accept(this);
    if (!isIndexColumn) {
      conditionTypes.add("And");
    }

    andExpression.getRightExpression().accept(this);

    if (!isIndexColumn) {
      conditionTypes.add("And");
    }
  }

  /**
   * Visit an OrExpression expression.
   *
   * @param orExpression the expression to visit
   */
  @Override
  public void visit(OrExpression orExpression) {
    orExpression.getLeftExpression().accept(this);

    if (!isIndexColumn) {
      conditionTypes.add("Or");
    }

    orExpression.getRightExpression().accept(this);

    if (!isIndexColumn) {
      conditionTypes.add("Or");
    }
  }

  /**
   * Constructs a single expression from the array of non-index usable selection conditions.
   *
   * @return the expression composed of all of the non-index usable selection conditions
   */
  public Expression flattenSelectConditions() {
    BinaryExpression compositeCondition = null;

    if (selectConditions.size() == 1) {
      return selectConditions.get(0);
    } else {
      if (conditionTypes.get(0) == "And") {
        compositeCondition =
            new AndExpression(selectConditions.remove(0), selectConditions.remove(0));
        conditionTypes.remove(0);
      } else if (conditionTypes.get(0) == "Or") {
        compositeCondition =
            new OrExpression(selectConditions.remove(0), selectConditions.remove(0));
        conditionTypes.remove(0);
      }
      for (int i = 0; i < selectConditions.size(); i++) {
        if (conditionTypes.get(i) == "And") {
          compositeCondition = new AndExpression(compositeCondition, selectConditions.get(i));
        } else if (conditionTypes.get(i) == "Or") {
          compositeCondition = new OrExpression(compositeCondition, selectConditions.get(i));
        }
      }
      return compositeCondition;
    }
  }
}
