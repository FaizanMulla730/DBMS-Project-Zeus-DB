package visitor;

import java.util.ArrayList;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.conditional.OrExpression;
import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.OrderByElement;
import operator.Operator;

/**
 * Extracts OrderBy elements from an expression to facilitate external sorting and sort-merge join
 * operations.
 */
public class OrderExtractionVisitor extends ConditionVisitor {
  private ArrayList<OrderByElement> leftOrderByElements;
  private ArrayList<OrderByElement> rightOrderByElements;
  private Operator leftOperator;
  private Operator rightOperator;

  /*Constructs a SortMergeJoinVisitor and initializes the class variables */
  public OrderExtractionVisitor(Operator lefOperator, Operator rightOperator) {
    this.leftOrderByElements = new ArrayList<OrderByElement>();
    this.rightOrderByElements = new ArrayList<OrderByElement>();
    this.leftOperator = lefOperator;
    this.rightOperator = rightOperator;
  }

  public ArrayList<OrderByElement> getLeftOrder() {
    return leftOrderByElements;
  }

  public ArrayList<OrderByElement> getRightOrder() {
    return rightOrderByElements;
  }

  /**
   * A method to check whether a given colum belongs to outer table
   *
   * @param Column A table column
   */
  public Boolean isOuterTableColumn(Column tableColumn) {
    if (leftOperator.getColumnNumberFromSchema(tableColumn) == -1) return false;
    else return true;
  }

  /**
   * A method to check whether a given colum belongs to inner table
   *
   * @param Column A table column
   */
  public Boolean isInnerTableColumn(Column tableColumn) {
    if (rightOperator.getColumnNumberFromSchema(tableColumn) == -1) return false;
    else return true;
  }

  @Override
  public void visit(AndExpression andExpression) {
    andExpression.getLeftExpression().accept(this);
    andExpression.getRightExpression().accept(this);
  }

  @Override
  public void visit(OrExpression orExpression) {
    orExpression.getLeftExpression().accept(this);
    orExpression.getRightExpression().accept(this);
  }

  @Override
  public void visit(EqualsTo equalsTo) {
    equalsTo.getLeftExpression().accept(this);
    equalsTo.getRightExpression().accept(this);
  }

  /**
   * This method evaluates whether join operation is a self join, determines which table the column
   * belongs to and creates a orderBy clause for that table.
   *
   * @param Column A table column
   */
  @Override
  public void visit(Column tableColumn) {

    if (isInnerTableColumn(tableColumn) && isOuterTableColumn(tableColumn)) {
      OrderByElement leftOrder = new OrderByElement();
      leftOrder.setExpression(tableColumn);
      leftOrderByElements.add(leftOrder);

      OrderByElement rightOrder = new OrderByElement();
      rightOrder.setExpression(tableColumn);
      rightOrderByElements.add(rightOrder);
    } else if (isOuterTableColumn(tableColumn)) {
      OrderByElement leftOrder = new OrderByElement();
      leftOrder.setExpression(tableColumn);
      leftOrderByElements.add(leftOrder);
    } else {
      OrderByElement rightOrder = new OrderByElement();
      rightOrder.setExpression(tableColumn);
      rightOrderByElements.add(rightOrder);
    }
  }
}
