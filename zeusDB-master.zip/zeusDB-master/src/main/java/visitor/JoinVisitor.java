package visitor;

import common.Tuple;
import net.sf.jsqlparser.expression.LongValue;
import net.sf.jsqlparser.schema.Column;
import operator.Operator;

/** JoinVisitor evaluates the join condition over the two given tuples */
public class JoinVisitor extends ConditionVisitor {
  private Tuple leftTuple;
  private Tuple rightTuple;
  private Operator leftOperator;
  private Operator rightOperator;
  private Boolean isOuterValueDispatched;

  /*Constructs a JoinVisitor and initializes the class variables */
  public JoinVisitor(Operator lefOperator, Operator rightOperator) {
    this.leftOperator = lefOperator;
    this.rightOperator = rightOperator;
    this.isOuterValueDispatched = false;
  }

  /**
   * A setter method to set the inner and outer tuples
   *
   * @param outer The outer tuple
   * @param inner The inner tuple
   */
  public void setTuples(Tuple outer, Tuple inner) {
    this.leftTuple = outer;
    this.rightTuple = inner;
  }

  /**
   * A method to check whether a given colum belongs to outer table
   *
   * @param Column A table column
   */
  public Boolean isOuterTableColumn(Column tableColumn) {
    if (leftOperator.getColumnNumberFromSchema(tableColumn) == -1) return false;
    else return true;
  }

  /**
   * A method to check whether a given colum belongs to inner table
   *
   * @param Column A table column
   */
  public Boolean isInnerTableColumn(Column tableColumn) {
    if (rightOperator.getColumnNumberFromSchema(tableColumn) == -1) return false;
    else return true;
  }

  /**
   * This method evaluates whether join operation is a self join, determines which table the column
   * belongs to and extracts and visits the value
   *
   * @param Column A table column
   */
  @Override
  public void visit(Column tableColumn) {
    Long columnValue;

    if (isInnerTableColumn(tableColumn) && isOuterTableColumn(tableColumn)) {
      if (isOuterValueDispatched) {
        columnValue =
            (long)
                rightTuple.getElementAtIndex(rightOperator.getColumnNumberFromSchema(tableColumn));
        isOuterValueDispatched = false;
      } else {
        columnValue =
            (long) leftTuple.getElementAtIndex(leftOperator.getColumnNumberFromSchema(tableColumn));
        isOuterValueDispatched = true;
      }
    } else if (isOuterTableColumn(tableColumn)) {
      columnValue =
          (long) leftTuple.getElementAtIndex(leftOperator.getColumnNumberFromSchema(tableColumn));
      isOuterValueDispatched = true;
    } else {
      columnValue =
          (long) rightTuple.getElementAtIndex(rightOperator.getColumnNumberFromSchema(tableColumn));
      isOuterValueDispatched = false;
    }

    LongValue columnLongValue = new LongValue(columnValue);
    columnLongValue.accept(this);
  }
}
