package visitor;

import net.sf.jsqlparser.expression.*;
import net.sf.jsqlparser.expression.operators.arithmetic.*;
import net.sf.jsqlparser.expression.operators.conditional.*;
import net.sf.jsqlparser.expression.operators.relational.*;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.*;

/**
 * ConditionVisitor implements the ExpressionVisitor and overrides certain methods to handle
 * operators in a query
 */
public class ConditionVisitor implements ExpressionVisitor {
  private Boolean resultCondition;
  private Long longValue;
  // resultDiffs is used to track the diff between to values being compared for SMJ!
  private Long resultDiff;

  public ConditionVisitor() {}

  /**
   * The getter method which returns the boolean output of the previously visited expression
   *
   * @return the boolean value
   */
  public Boolean getResultCondition() {
    return resultCondition;
  }

  public Long getLongValue() {
    return longValue;
  }

  /**
   * Uses resultDiff to determine which evaluated expression value was greater (left > right or
   * right > left). Returns the result as a boolean.
   *
   * @return the boolean value
   */
  public Boolean evaluateResultDiff() {
    if (resultDiff < 0) {
      return false;
    }
    return true;
  }

  /**
   * Overridden method from parent Interface which return the value from LongValue
   *
   * @param longVal The longValue
   */
  @Override
  public void visit(LongValue longVal) {
    longValue = longVal.getValue();
  }

  @Override
  public void visit(Column tableColumn) {
    tableColumn.accept(this);
  }

  /**
   * Overridden method from parent Interface. Checks the equality relation in expression and updates
   * the resultCondition
   *
   * @param equalsTo The equalsTo operator
   */
  @Override
  public void visit(EqualsTo equalsTo) {
    equalsTo.getLeftExpression().accept(this);
    Long leftValue = longValue;
    equalsTo.getRightExpression().accept(this);
    Long rightValue = longValue;

    resultCondition = leftValue.equals(rightValue);
    // As mentioned above we are setting this just for resultDiff.
    // This is probably not the cleanest way of doing this but it is definitely easiest.
    // Refactoring is required!
    resultDiff = leftValue - rightValue;
  }

  /**
   * Overridden method from parent Interface. Checks the Inequality relation in expression and
   * updates the resultCondition
   *
   * @param notEqualsTo The inequality operator
   */
  @Override
  public void visit(NotEqualsTo notEqualsTo) {
    notEqualsTo.getLeftExpression().accept(this);
    Long leftValue = longValue;
    notEqualsTo.getRightExpression().accept(this);
    Long rightValue = longValue;

    resultCondition = leftValue != rightValue;
  }

  /**
   * Overridden method from parent Interface. Checks the greaterThan relation in expression and
   * updates the resultCondition
   *
   * @param greaterThan The greaterThan operator
   */
  @Override
  public void visit(GreaterThan greaterThan) {
    greaterThan.getLeftExpression().accept(this);
    Long leftValue = longValue;
    greaterThan.getRightExpression().accept(this);
    Long rightValue = longValue;

    resultCondition = leftValue > rightValue;
  }

  /**
   * Overridden method from parent Interface. Checks the greaterThanEquals relation in expression
   * and updates the resultCondition
   *
   * @param greaterThanEquals The greaterThan operator
   */
  @Override
  public void visit(GreaterThanEquals greaterThanEquals) {
    greaterThanEquals.getLeftExpression().accept(this);
    Long leftValue = longValue;
    greaterThanEquals.getRightExpression().accept(this);
    Long rightValue = longValue;

    resultCondition = leftValue >= rightValue;
  }

  /**
   * Overridden method from parent Interface. Checks the minorThan relation in expression and
   * updates the resultCondition
   *
   * @param minorThan The minorThan operator
   */
  @Override
  public void visit(MinorThan minorThan) {
    minorThan.getLeftExpression().accept(this);
    Long leftValue = longValue;
    minorThan.getRightExpression().accept(this);
    Long rightValue = longValue;

    resultCondition = leftValue < rightValue;
  }

  /**
   * Overridden method from parent Interface. Checks the minorThanEquals relation in expression and
   * updates the resultCondition
   *
   * @param minorThanEquals The minorThanEquals operator
   */
  @Override
  public void visit(MinorThanEquals minorThanEquals) {
    minorThanEquals.getLeftExpression().accept(this);
    Long leftValue = longValue;
    minorThanEquals.getRightExpression().accept(this);
    Long rightValue = longValue;

    resultCondition = leftValue <= rightValue;
  }

  /**
   * Overridden method from parent Interface. Checks the andExpression relation in expression and
   * updates the resultCondition
   *
   * @param andExpression The andExpression operator
   */
  @Override
  public void visit(AndExpression andExpression) {
    andExpression.getLeftExpression().accept(this);
    Boolean leftCondition = resultCondition;
    andExpression.getRightExpression().accept(this);
    Boolean rightCondition = resultCondition;

    resultCondition = leftCondition && rightCondition;
  }

  /**
   * Overridden method from parent Interface. Checks the orExpression relation in expression and
   * updates the resultCondition
   *
   * @param orExpression The orExpression operator
   */
  @Override
  public void visit(OrExpression orExpression) {
    orExpression.getLeftExpression().accept(this);
    Boolean leftCondition = resultCondition;
    orExpression.getRightExpression().accept(this);
    Boolean rightCondition = resultCondition;

    resultCondition = leftCondition || rightCondition;
  }

  public void visit(Addition addition) {}

  public void visit(AnyComparisonExpression allComparisonExpression) {}

  public void visit(AnalyticExpression aexpr) {}

  public void visit(Between between) {}

  public void visit(BitwiseAnd bitwiseAnd) {}

  public void visit(BitwiseOr bitwiseOr) {}

  public void visit(BitwiseXor bitwiseXor) {}

  public void visit(CaseExpression caseExpression) {}

  public void visit(CastExpression cast) {}

  public void visit(Concat concat) {}

  public void visit(DateValue dateValue) {}

  public void visit(Division division) {}

  public void visit(DoubleValue doubleValue) {}

  public void visit(ExistsExpression existsExpression) {}

  public void visit(ExtractExpression eexpr) {}

  public void visit(Function function) {}

  public void visit(HexValue hexValue) {}

  public void visit(InExpression inExpression) {}

  public void visit(IntervalExpression iexpr) {}

  public void visit(IsNullExpression isNullExpression) {}

  public void visit(JdbcNamedParameter jdbcNamedParameter) {}

  public void visit(JdbcParameter jdbcParameter) {}

  public void visit(JsonExpression jsonExpr) {}

  public void visit(KeepExpression aexpr) {}

  public void visit(LikeExpression likeExpression) {}

  public void visit(Matches matches) {}

  public void visit(Modulo modulo) {}

  public void visit(Multiplication multiplication) {}

  public void visit(MySQLGroupConcat groupConcat) {}

  public void visit(NullValue nullValue) {}

  public void visit(NumericBind bind) {}

  public void visit(OracleHierarchicalExpression oexpr) {}

  public void visit(OracleHint hint) {}

  public void visit(Parenthesis parenthesis) {}

  public void visit(RegExpMatchOperator rexpr) {}

  public void visit(RegExpMySQLOperator regExpMySQLOperator) {}

  public void visit(RowConstructor rowConstructor) {}

  public void visit(SignedExpression signedExpression) {}

  public void visit(StringValue stringValue) {}

  public void visit(SubSelect subSelect) {}

  public void visit(Subtraction subtraction) {}

  public void visit(TimestampValue timestampValue) {}

  public void visit(TimeValue timeValue) {}

  public void visit(UserVariable var) {}

  public void visit(WhenClause whenClause) {}

  public void visit(BitwiseRightShift aThis) {}

  public void visit(BitwiseLeftShift aThis) {}

  public void visit(IntegerDivision division) {}

  public void visit(XorExpression orExpression) {}

  public void visit(OverlapsCondition overlapsCondition) {}

  public void visit(FullTextSearch fullTextSearch) {}

  public void visit(IsBooleanExpression isBooleanExpression) {}

  public void visit(TryCastExpression cast) {}

  public void visit(SafeCastExpression cast) {}

  public void visit(JsonOperator jsonExpr) {}

  public void visit(ValueListExpression valueList) {}

  public void visit(RowGetExpression rowGetExpression) {}

  public void visit(TimeKeyExpression timeKeyExpression) {}

  public void visit(DateTimeLiteralExpression literal) {}

  public void visit(NotExpression aThis) {}

  public void visit(NextValExpression aThis) {}

  public void visit(CollateExpression aThis) {}

  public void visit(SimilarToExpression aThis) {}

  public void visit(ArrayExpression aThis) {}

  public void visit(ArrayConstructor aThis) {}

  public void visit(VariableAssignment aThis) {}

  public void visit(XMLSerializeExpr aThis) {}

  public void visit(TimezoneExpression aThis) {}

  public void visit(JsonAggregateFunction aThis) {}

  public void visit(JsonFunction aThis) {}

  public void visit(ConnectByRootOperator aThis) {}

  public void visit(OracleNamedFunctionParameter aThis) {}

  public void visit(AllColumns allColumns) {}

  public void visit(AllTableColumns allTableColumns) {}

  public void visit(AllValue allValue) {}

  public void visit(IsDistinctExpression isDistinctExpression) {}

  public void visit(GeometryDistance geometryDistance) {}
}
