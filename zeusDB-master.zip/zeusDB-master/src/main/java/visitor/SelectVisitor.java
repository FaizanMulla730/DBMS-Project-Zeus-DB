package visitor;

import common.Tuple;
import net.sf.jsqlparser.expression.LongValue;
import net.sf.jsqlparser.schema.Column;
import operator.Operator;

/**
 * SelectVisitor will take as input a tuple and recursively walk through the expressions/conditions
 * and evaluate it to a boolean on that tuple.
 */
public class SelectVisitor extends ConditionVisitor {
  private Tuple inputTuple;
  private Operator operator;

  /** Constructs a SelectVisitor. */
  public SelectVisitor(Operator operator) {
    this.operator = operator;
  }

  /**
   * Sets inputTuple variable.
   *
   * @param inputTuple tuple to evaluate.
   */
  public void setInputTuple(Tuple inputTuple) {
    this.inputTuple = inputTuple;
  }

  /**
   * Overrides the visit(Column column) to extract value in column
   *
   * @param Column A column object
   */
  @Override
  public void visit(Column column) {
    int columnIndex = operator.getColumnNumberFromSchema(column);
    Long columnValue = (long) inputTuple.getElementAtIndex(columnIndex);
    LongValue columnLongValue = new LongValue(columnValue);
    columnLongValue.accept(this);
  }
}
