package visitor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.jsqlparser.expression.*;
import net.sf.jsqlparser.schema.*;
import net.sf.jsqlparser.statement.select.*;

/*
 * Class which is used to generate a mapping of Alias to Table. The logic is implemented
 * in such a way that, all the aliases in the query is replaced by table names.We are
 * resolving the column references through this class
 */

public class AliasVisitor {
  private final Map<String, String> aliasMapping;

  public AliasVisitor() {
    this.aliasMapping = new HashMap<>();
  }

  /**
   * A method which calls another method to parse the statement and generate the map
   *
   * @param select The select statement
   * @return Return the map of alias to tables
   */
  public void processQuery(Select select) {
    processSelectBody(select.getSelectBody());
  }

  /**
   * This method parses the SQL statement and retrieves the fromItem, joins, where and
   * orderByelements
   *
   * @param selectBody selectBody of the query
   * @return Return the map of alias to tables
   */
  private void processSelectBody(SelectBody selectBody) {
    if (selectBody instanceof PlainSelect) {
      PlainSelect plainSelect = (PlainSelect) selectBody;
      processFromItem(plainSelect.getFromItem());
      processJoinItem(plainSelect.getJoins());

      if (plainSelect.getWhere() != null) {
        plainSelect
            .getWhere()
            .accept(
                new ExpressionVisitorAdapter() {
                  @Override
                  public void visit(Column column) {
                    processColumn(column);
                  }
                });
      }

      if (plainSelect.getOrderByElements() != null) {
        List<OrderByElement> orderBy = new ArrayList<OrderByElement>();
        orderBy = plainSelect.getOrderByElements();
        for (int i = 0; i < orderBy.size(); i++) {
          orderBy
              .get(i)
              .getExpression()
              .accept(
                  new ExpressionVisitorAdapter() {
                    @Override
                    public void visit(Column column) {
                      processColumn(column);
                    }
                  });
        }
      }
      for (SelectItem selectItem : plainSelect.getSelectItems()) {
        selectItem.accept(
            new SelectItemVisitorAdapter() {
              @Override
              public void visit(SelectExpressionItem item) {
                Expression expression = item.getExpression();
                if (expression instanceof Column) {
                  processColumn((Column) expression);
                }
              }
            });
      }
    }
  }

  /**
   * A method to generate the Map from Aliases and tableNames
   *
   * @param fromItem the fromItem from PlainSelect
   */
  private void processFromItem(FromItem fromItem) {
    if (fromItem instanceof Table) {
      Table table = (Table) fromItem;
      if (table.getAlias() != null) {
        String alias = table.getAlias().getName();
        aliasMapping.put(alias, table.getName());
      }
    }
  }

  /**
   * A method to extract table names from joinItems. It will populate the map
   *
   * @param List<Join>joins An arraylist of joins
   */
  private void processJoinItem(List<Join> joins) {
    if (joins != null) {
      for (int i = 0; i < joins.size(); i++) {
        Table table = (Table) joins.get(i).getRightItem();
        if (table.getAlias() != null) {
          String alias = table.getAlias().getName();
          aliasMapping.put(alias, table.getName());
        }
      }
    }
  }

  /**
   * This method replaces the table name column in the Column Object. The table name is an alias in
   * the Column Object, this gets replaced by table name
   *
   * @param Column A column object
   */
  private void processColumn(Column column) {
    String alias = column.getTable() != null ? column.getTable().getName() : null;
    if (alias != null && aliasMapping.containsKey(alias)) {
      // Replace the alias with the resolved table name
      column.getTable().setName(aliasMapping.get(alias));
      column.getTable().setAlias(new Alias(alias));
    }
  }
}
