package builder;

import java.util.ArrayList;
import java.util.HashMap;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.LongValue;
import net.sf.jsqlparser.expression.operators.conditional.*;
import net.sf.jsqlparser.expression.operators.relational.*;
import net.sf.jsqlparser.schema.Column;
import union_find.Element;
import union_find.UnionFind;
import visitor.ConditionVisitor;

public class UnionFindBuilder extends ConditionVisitor {
  private UnionFind unionFind;
  private ArrayList<Expression> residualExpressions;
  private Column currentColumn;
  private Long currentLong;
  private HashMap<String, ArrayList<Expression>> joinConditions;

  public UnionFindBuilder() {
    this.unionFind = new UnionFind();
    this.residualExpressions = new ArrayList<Expression>();
    this.currentColumn = null;
    this.currentLong = null;
    this.joinConditions = new HashMap<>();
  }

  /**
   * A helper method which adds the table name and join condition to map
   *
   * @param tableName The name of table
   * @param exp The expression associated to the particular table
   */
  private void addJoinCondition(String tableName, Expression exp) {
    if (joinConditions.containsKey(tableName)) {
      joinConditions.get(tableName).add(exp);
    } else {
      ArrayList<Expression> joinExpressions = new ArrayList<Expression>();
      joinExpressions.add(exp);
      joinConditions.put(tableName, joinExpressions);
    }
  }

  public UnionFind getUnionFind() {
    return unionFind;
  }

  public ArrayList<Expression> getResidualExpressions() {
    return residualExpressions;
  }

  /**
   * A method which the map of table names to join expressions which reference them
   *
   * @return Map of table and their associated join expressions
   */
  public HashMap<String, ArrayList<Expression>> getJoinConditions() {
    return joinConditions;
  }

  public void resetValues() {
    currentColumn = null;
    currentLong = null;
  }

  @Override
  public void visit(LongValue longValue) {
    currentColumn = null;
    currentLong = longValue.getValue();
  }

  @Override
  public void visit(Column column) {
    currentLong = null;
    currentColumn = column;
  }

  @Override
  public void visit(EqualsTo equalsTo) {
    equalsTo.getLeftExpression().accept(this);
    if (currentColumn != null) {

      Column leftColumn = currentColumn;
      Element leftElement = unionFind.create(leftColumn);
      equalsTo.getRightExpression().accept(this);

      // if the comparison has the form att1 = att2, find the two elements containing att1 and att2
      // and union them
      if (currentColumn != null) {
        Column rightColumn = currentColumn;
        Element rightElement = unionFind.create(rightColumn);
        unionFind.union(leftElement, rightElement);
        addJoinCondition(leftColumn.getTable().getName(), (Expression) equalsTo);
      } else {
        // if the comparison has the form att OP val, where val is an integer, find the
        // element containing att and update the appropriate numeric bound in the element
        long rightLong = (long) currentLong;
        unionFind.setElementEqualityConstraint(leftElement, (int) rightLong);
      }
    } else {
      long leftLong = (long) currentLong;
      equalsTo.getRightExpression().accept(this);
      Column rightColumn = currentColumn;
      Element rightElement = unionFind.create(rightColumn);
      unionFind.setElementEqualityConstraint(rightElement, (int) leftLong);
    }
  }

  @Override
  public void visit(NotEqualsTo notEqualsTo) {
    residualExpressions.add(notEqualsTo);
  }

  @Override
  public void visit(GreaterThan greaterThan) {
    greaterThan.getLeftExpression().accept(this);
    if (currentColumn != null) {

      Column leftColumn = currentColumn;
      Element leftElement = unionFind.create(leftColumn);
      greaterThan.getRightExpression().accept(this);

      // if the comparison has the form att1 = att2, find the two elements containing att1 and att2
      // and union them
      if (currentColumn != null) {
        residualExpressions.add(greaterThan);
      } else {
        // if the comparison has the form att OP val, where val is an integer, find the
        // element containing att and update the appropriate numeric bound in the element
        long rightLong = (long) currentLong;
        unionFind.setElementLowerBound(leftElement, (int) rightLong + 1);
      }
    } else {
      long leftLong = (long) currentLong;
      greaterThan.getRightExpression().accept(this);
      Column rightColumn = currentColumn;
      Element rightElement = unionFind.create(rightColumn);
      unionFind.setElementUpperBound(rightElement, (int) leftLong - 1);
    }
  }

  @Override
  public void visit(GreaterThanEquals greaterThanEquals) {
    greaterThanEquals.getLeftExpression().accept(this);
    if (currentColumn != null) {

      Column leftColumn = currentColumn;
      Element leftElement = unionFind.create(leftColumn);
      greaterThanEquals.getRightExpression().accept(this);

      // if the comparison has the form att1 = att2, find the two elements containing att1 and att2
      // and union them
      if (currentColumn != null) {
        residualExpressions.add(greaterThanEquals);
      } else {
        // if the comparison has the form att OP val, where val is an integer, find the
        // element containing att and update the appropriate numeric bound in the element
        long rightLong = (long) currentLong;
        unionFind.setElementLowerBound(leftElement, (int) rightLong);
      }
    } else {
      long leftLong = (long) currentLong;
      greaterThanEquals.getRightExpression().accept(this);
      Column rightColumn = currentColumn;
      Element rightElement = unionFind.create(rightColumn);
      unionFind.setElementUpperBound(rightElement, (int) leftLong);
    }
  }

  @Override
  public void visit(MinorThan minorThan) {
    minorThan.getLeftExpression().accept(this);
    if (currentColumn != null) {

      Column leftColumn = currentColumn;
      Element leftElement = unionFind.create(leftColumn);
      minorThan.getRightExpression().accept(this);

      // if the comparison has the form att1 = att2, find the two elements containing att1 and att2
      // and union them
      if (currentColumn != null) {
        residualExpressions.add(minorThan);
      } else {
        // if the comparison has the form att OP val, where val is an integer, find the
        // element containing att and update the appropriate numeric bound in the element
        long rightLong = (long) currentLong;
        unionFind.setElementUpperBound(leftElement, (int) rightLong - 1);
      }
    } else {
      long leftLong = (long) currentLong;
      minorThan.getRightExpression().accept(this);
      Column rightColumn = currentColumn;
      Element rightElement = unionFind.create(rightColumn);
      unionFind.setElementLowerBound(rightElement, (int) leftLong + 1);
    }
  }

  @Override
  public void visit(MinorThanEquals minorThanEquals) {
    minorThanEquals.getLeftExpression().accept(this);
    if (currentColumn != null) {

      Column leftColumn = currentColumn;
      Element leftElement = unionFind.create(leftColumn);
      minorThanEquals.getRightExpression().accept(this);

      // if the comparison has the form att1 = att2, find the two elements containing att1 and att2
      // and union them
      if (currentColumn != null) {
        residualExpressions.add(minorThanEquals);
      } else {
        // if the comparison has the form att OP val, where val is an integer, find the
        // element containing att and update the appropriate numeric bound in the element
        long rightLong = (long) currentLong;
        unionFind.setElementUpperBound(leftElement, (int) rightLong);
      }
    } else {
      long leftLong = (long) currentLong;
      minorThanEquals.getRightExpression().accept(this);
      Column rightColumn = currentColumn;
      Element rightElement = unionFind.create(rightColumn);
      unionFind.setElementLowerBound(rightElement, (int) leftLong);
    }
  }

  @Override
  public void visit(AndExpression andExpression) {
    andExpression.getLeftExpression().accept(this);
    andExpression.getRightExpression().accept(this);
  }

  @Override
  public void visit(OrExpression orExpression) {}
}
