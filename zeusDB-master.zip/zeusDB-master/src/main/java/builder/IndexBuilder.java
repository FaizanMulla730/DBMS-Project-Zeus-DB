package builder;

import btree.Btree;
import common.DBCatalog;
import common.Index;
import java.util.ArrayList;
import java.util.Arrays;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.OrderByElement;
import operator.ExternalSortOperator;
import operator.Operator;
import operator.ScanOperator;
import util.Constants;

/** A utility class responsible for building and managing indexes for database tables. */
public class IndexBuilder {
  /**
   * Sorts the specified table's relation based on the given index column and replaces the original
   * relation with the sorted one.
   *
   * @param index The Index object containing information about the column to be indexed.
   */
  public void sortAndReplaceRelation(Index index) {
    Column indexColumn = index.getIndexColumn();
    String tableName = indexColumn.getTable().getName();
    ArrayList<Column> outputSchema = DBCatalog.getDB().getTableColumns(tableName);
    OrderByElement orderBy = new OrderByElement();
    orderBy.setExpression(indexColumn);

    Operator sortOperator =
        new ExternalSortOperator(
            outputSchema,
            new ScanOperator(outputSchema),
            Arrays.asList(orderBy),
            DBCatalog.getDB().getTempDirectory(),
            Constants.Sort.PAGES);

    sortOperator.dump(DBCatalog.getDB().getFileForTable(tableName));
  }

  /**
   * Iterates through the indexes in the database catalog, creates B-tree indexes for non-clustered
   * indexes, and sorts and replaces relations for clustered indexes. This method is responsible for
   * building and managing indexes for the entire database.
   */
  public void createIndexes() {
    for (Index index : DBCatalog.getDB().getAllIndexes()) {
      if (index.isClustered()) {
        sortAndReplaceRelation(index);
      }
      Btree btree = new Btree(index);
      btree.constructAndSerialize();
    }
  }
}
