package builder;

import common.DBCatalog;
import common.Index;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import logical.*;
import net.sf.jsqlparser.expression.BinaryExpression;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.select.OrderByElement;
import operator.*;
import optimizer.SelectionCostEstimator;
import util.Constants;
import visitor.IndexVisitor;
import visitor.OrderExtractionVisitor;

/**
 * PhyicalPlanBuilder class used to create a Physical Operator Tree based on Logical Plan,
 * Configuration file, and SQL query.
 */
public class PhysicalPlanBuilder {
  private Operator currentPhysical;

  public PhysicalPlanBuilder() {}

  /*
   * returns the currentPhysical Operator class variable
   */
  public Operator getCurrentPhysical() {
    return currentPhysical;
  }

  /**
   * visitor function that accepts a logicalOperator type
   *
   * @param op LogicalOperator object
   */
  public void visit(LogicalOperator op) {
    op.accept(this);
  }

  /**
   * visitor function that accepts a LogicalDistinct type and updates the PhysicalTree by creating a
   * new DuplicateEliminationOperator
   *
   * @param op LogicalDistinct object
   */
  public void visit(LogicalDistinct op) {
    op.getChild().accept(this);
    currentPhysical = new DuplicateEliminationOperator(op.getSchema(), currentPhysical);
  }

  public void visit(LogicalCrossJoin op) {
    op.getLeftChild().accept(this);
    Operator leftPhysical = currentPhysical;
    op.getRightChild().accept(this);
    Operator rightPhysical = currentPhysical;
    currentPhysical =
        new BlockNestedJoinOperator(
            op.getSchema(), Constants.Join.PAGES, leftPhysical, rightPhysical, null);
  }

  /**
   * visitor function that accepts a LogicalProject type and updates the PhysicalTree by creating a
   * new ProjectOperator
   *
   * @param op LogicalProject object
   */
  public void visit(LogicalProject op) {
    op.getChild().accept(this);
    currentPhysical = new ProjectOperator(op.getSchema(), currentPhysical, op.getColumns());
  }

  /**
   * visitor function that accepts a LogicalScan type and updates the PhysicalTree by creating a new
   * ScanOperator
   *
   * @param op LogicalScan object
   */
  public void visit(LogicalScan op) {
    currentPhysical = new ScanOperator(op.getSchema());
  }

  public Index getColumnIndex(Column column, ArrayList<Index> tableIndexes) {
    for (Index index : tableIndexes) {
      if (column.equals(index.getIndexColumn())) {
        return index;
      }
    }
    return null;
  }

  /**
   * visitor function that accepts a LogicalSelect type and updates the PhysicalTree by creating a
   * new SelectOperator
   *
   * @param op LogicalSelect object
   */
  public void visit(LogicalSelect op) {
    op.getChild().accept(this);
    HashMap<String, ArrayList<Index>> indexes = DBCatalog.getDB().getIndexMapping();
    SelectionCostEstimator costEstimator = new SelectionCostEstimator();
    Index optimalIndex = null;
    Integer optimalIndexScanCost = Integer.MAX_VALUE;

    // In the given schema, find the cost for all columns that have indexes
    // Out of all these columns, find the one that has the least cost.
    if (!indexes.isEmpty() && currentPhysical instanceof ScanOperator) {

      Index index = null;
      Integer indexScanCost = null;

      for (Column col : op.getSchema()) {

        String tableName = col.getTable().getName();

        if (indexes.containsKey(tableName)) {

          index = getColumnIndex(col, indexes.get(tableName));

          if (index != null) {
            IndexVisitor indexVisit = new IndexVisitor(index.getIndexColumn());
            op.getSelectCondition().accept(indexVisit);
            indexScanCost =
                costEstimator.calculateIndexScanCost(
                    op.getSchema(), index, indexVisit.getLowerBound(), indexVisit.getUpperBound());
            if (indexScanCost < optimalIndexScanCost) {
              optimalIndex = index;
              optimalIndexScanCost = indexScanCost;
            }
          }
        }
      }

      if (optimalIndex != null) {
        Integer scanCost = costEstimator.calculateScanCost(op.getSchema());
        IndexVisitor indexVisit = new IndexVisitor(optimalIndex.getIndexColumn());
        op.getSelectCondition().accept(indexVisit);

        if (indexVisit.useIndex()
            && indexVisit.getSelectConditions().isEmpty()
            && optimalIndexScanCost < scanCost) {
          currentPhysical =
              new IndexScanOperator(
                  op.getSchema(),
                  currentPhysical,
                  indexVisit.getLowerBound(),
                  indexVisit.getUpperBound(),
                  optimalIndex);
        } else if (indexVisit.useIndex() && !indexVisit.getSelectConditions().isEmpty()) {
          Integer scanCostAfterIndex =
              costEstimator.calculateScanCostAfterIndex(
                  op.getSchema(), costEstimator.getIndexResultNumTuples());
          if ((indexScanCost + scanCostAfterIndex) < scanCost) {
            currentPhysical =
                new IndexScanOperator(
                    op.getSchema(),
                    currentPhysical,
                    indexVisit.getLowerBound(),
                    indexVisit.getUpperBound(),
                    optimalIndex);
            currentPhysical =
                new SelectOperator(
                    op.getSchema(), currentPhysical, indexVisit.flattenSelectConditions());
          }
        }
      }
    }
    if (currentPhysical instanceof ScanOperator) {
      currentPhysical =
          new SelectOperator(op.getSchema(), currentPhysical, op.getSelectCondition());
    }
  }

  /**
   * visitor function that accepts a LogicalSort type and updates the PhysicalTree by creating a new
   * SortOperator
   *
   * @param op LogicalSort object
   */
  public void visit(LogicalSort op) {
    op.getChild().accept(this);

    currentPhysical =
        new ExternalSortOperator(
            op.getSchema(),
            currentPhysical,
            op.getOrderConditions(),
            DBCatalog.getDB().getTempDirectory(),
            Constants.Sort.PAGES);
  }

  /**
   * Creates a single branched tree of all select operators for the given table.
   *
   * @param table Table object
   * @param schema List of column objects
   * @return Tree of select operators for given table.
   */
  public Operator createJoinSubtree(
      Table table, HashMap<String, LogicalOperator> logicalSelections) {
    logicalSelections.get(table.getName()).accept(this);
    return currentPhysical;
  }

  /**
   * Joins subtrees together to create a join tree.
   *
   * @param joinExpression Expression that joins two tables.
   * @param childOperator Join operator for one of the tables in the given expression.
   * @return
   */
  public Operator createJoinTree(
      ArrayList<Expression> joinExpressions,
      Operator childOperator,
      HashMap<String, LogicalOperator> logicalSelections) {
    BinaryExpression joinExpression = (BinaryExpression) joinExpressions.get(0);

    Column leftColumn = (Column) ((BinaryExpression) joinExpression).getLeftExpression();
    Table leftTable = leftColumn.getTable();

    Column rightColumn = (Column) ((BinaryExpression) joinExpression).getRightExpression();
    Table rightTable = rightColumn.getTable();

    // If childOperator is null create new leftSubtree and rightSubtree
    // Otherwise determine its position based on the expression.
    Operator leftSubtreeRoot = null;
    Operator rightSubtreeRoot = null;
    if (childOperator == null) {
      leftSubtreeRoot = createJoinSubtree(leftTable, logicalSelections);
      rightSubtreeRoot = createJoinSubtree(rightTable, logicalSelections);
    } else if (childOperator.getColumnNumberFromSchema(leftColumn) != -1) {
      rightSubtreeRoot = createJoinSubtree(rightTable, logicalSelections);
      leftSubtreeRoot = childOperator;
    } else if (childOperator.getColumnNumberFromSchema(rightColumn) != -1) {
      leftSubtreeRoot = createJoinSubtree(leftTable, logicalSelections);
      rightSubtreeRoot = childOperator;
    }

    ArrayList<Column> combinedSchema = new ArrayList<>();
    combinedSchema.addAll(leftSubtreeRoot.getOutputSchema());
    combinedSchema.addAll(rightSubtreeRoot.getOutputSchema());

    if (joinExpressions.size() > 1) {
      for (int i = 1; i < joinExpressions.size(); i++) {
        joinExpression = new AndExpression(joinExpression, joinExpressions.get(i));
      }
      return new BlockNestedJoinOperator(
          combinedSchema, Constants.Join.PAGES, leftSubtreeRoot, rightSubtreeRoot, joinExpression);
    } else if (joinExpression instanceof EqualsTo) {
      // Create sort orders for left and right child using the join conditions
      OrderExtractionVisitor smjVisitor =
          new OrderExtractionVisitor(leftSubtreeRoot, rightSubtreeRoot);
      joinExpression.accept(smjVisitor);

      // Retrieve the sort order for left and right input streams from the join condition
      ArrayList<OrderByElement> leftOrderByElements = smjVisitor.getLeftOrder();
      ArrayList<OrderByElement> rightOrderByElements = smjVisitor.getRightOrder();

      Operator leftSortOperator =
          new ExternalSortOperator(
              leftSubtreeRoot.getOutputSchema(),
              leftSubtreeRoot,
              leftOrderByElements,
              DBCatalog.getDB().getTempDirectory(),
              Constants.Sort.PAGES);

      Operator rightSortOperator =
          new ExternalSortOperator(
              rightSubtreeRoot.getOutputSchema(),
              rightSubtreeRoot,
              rightOrderByElements,
              DBCatalog.getDB().getTempDirectory(),
              Constants.Sort.PAGES);

      return new SortMergeJoinOperator(
          combinedSchema, leftSortOperator, rightSortOperator, joinExpression);
    } else {
      return new BlockNestedJoinOperator(
          combinedSchema, Constants.Join.PAGES, leftSubtreeRoot, rightSubtreeRoot, joinExpression);
    }
  }

  public void visit(LogicalMultiJoin op) {
    List<Table> joinOrder = op.getOptimalJoinOrder();
    HashMap<String, LogicalOperator> logicalSelections = op.getLogicalSelections();
    HashMap<String, ArrayList<Expression>> joinConditions = op.getJoinConditions();
    ArrayList<Expression> residualExpressions = op.getResidualExpressions();

    Operator joinRootOperator = null;
    for (Table table : joinOrder) {
      ArrayList<Expression> joinExpressions = joinConditions.get(table.getName());
      if (joinExpressions != null && !joinExpressions.isEmpty()) {
        joinRootOperator = createJoinTree(joinExpressions, joinRootOperator, logicalSelections);
      }
    }
    if (residualExpressions.size() > 0) {
      joinRootOperator = createJoinTree(residualExpressions, joinRootOperator, logicalSelections);
    }
    currentPhysical = joinRootOperator;
  }
}
