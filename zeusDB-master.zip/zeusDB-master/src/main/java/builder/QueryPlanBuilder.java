package builder;

import common.DBCatalog;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import logical.*;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.expression.LongValue;
import net.sf.jsqlparser.expression.operators.conditional.AndExpression;
import net.sf.jsqlparser.expression.operators.relational.EqualsTo;
import net.sf.jsqlparser.expression.operators.relational.GreaterThanEquals;
import net.sf.jsqlparser.expression.operators.relational.MinorThanEquals;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.*;
import operator.*;
import optimizer.VValueManager;
import union_find.Element;
import union_find.UnionFind;
import visitor.AliasVisitor;

/**
 * Class to translate a JSQLParser statement into a relational algebra query plan. For now only
 * works for Statements that are Selects, and specifically PlainSelects. Could implement the visitor
 * pattern on the statement, but doesn't for simplicity as we do not handle nesting or other complex
 * query features.
 *
 * <p>Query plan fixes join order to the order found in the from clause and uses a left deep tree
 * join. Maximally pushes selections on individual relations and evaluates join conditions as early
 * as possible in the join tree. Projections (if any) are not pushed and evaluated in a single
 * projection operator after the last join. Finally, sorting and duplicate elimination are added if
 * needed.
 */
public class QueryPlanBuilder {
  private Select selectStmt;
  private List<SelectItem> selectItems;
  private Distinct distinct;
  private Table fromTable;
  private List<Join> joins;
  private Expression where;
  private List<OrderByElement> orderByElements;
  private ArrayList<Table> joinOrder;
  private LogicalOperator rootOperator;
  private ArrayList<Column> outputSchema;
  private VValueManager vValueManager;

  public QueryPlanBuilder() {
    this.vValueManager = new VValueManager();
  }

  private Expression createSelectCondition(ArrayList<Expression> selectExpressions) {
    if (selectExpressions.size() == 1) {
      return selectExpressions.get(0);
    } else {
      Expression leftExp = selectExpressions.get(0);
      Expression rightExp = selectExpressions.get(1);
      AndExpression selectCondition = new AndExpression(leftExp, rightExp);
      for (int i = 2; i < selectExpressions.size(); i++) {
        selectCondition = new AndExpression(selectCondition, selectExpressions.get(i));
      }
      return selectCondition;
    }
  }

  private HashMap<String, LogicalOperator> generateLogicalSelections(UnionFind unionFind) {
    HashMap<String, LogicalOperator> logicalSelections = new HashMap<String, LogicalOperator>();
    ArrayList<Expression> selectExpressions = new ArrayList<Expression>();

    for (Table table : joinOrder) {
      String tableName = table.getName();
      ArrayList<Column> schema = DBCatalog.getDB().getTableColumns(tableName);
      LogicalOperator tableOperator = new LogicalScan(schema);

      for (Column column : schema) {
        Expression leftExpression = column;
        Element element = unionFind.find(column);

        if (element != null) {
          if (element.getEqualityConstraint() != null) {
            Expression righExpression = new LongValue(element.getEqualityConstraint());
            EqualsTo equals = new EqualsTo(leftExpression, righExpression);
            selectExpressions.add(equals);
            vValueManager.addTableVValues(
                tableName,
                column,
                element.getEqualityConstraint(),
                element.getEqualityConstraint());
          } else {
            if (element.getLowerBound() != null) {
              Expression righExpression = new LongValue(element.getLowerBound());
              GreaterThanEquals greaterThanEquals = new GreaterThanEquals();
              greaterThanEquals.setLeftExpression(leftExpression);
              greaterThanEquals.setRightExpression(righExpression);
              selectExpressions.add(greaterThanEquals);
            }
            if (element.getUpperBound() != null) {
              Expression righExpression = new LongValue(element.getUpperBound());
              MinorThanEquals minorThanEquals = new MinorThanEquals();
              minorThanEquals.setLeftExpression(leftExpression);
              minorThanEquals.setRightExpression(righExpression);
              selectExpressions.add(minorThanEquals);
            }
            vValueManager.addTableVValues(
                tableName, column, element.getLowerBound(), element.getUpperBound());
          }
        }
      }
      if (selectExpressions.size() > 0) {
        Expression selectCondition = createSelectCondition(selectExpressions);
        tableOperator = new LogicalSelect(schema, tableOperator, selectCondition);
        selectExpressions.clear();
      }
      logicalSelections.put(tableName, tableOperator);
    }
    return logicalSelections;
  }

  public LogicalOperator getRootJoinOperator() {
    UnionFindBuilder unionFindBuilder = new UnionFindBuilder();
    where.accept(unionFindBuilder);

    UnionFind unionFind = unionFindBuilder.getUnionFind();
    ArrayList<Expression> residualExpressions = unionFindBuilder.getResidualExpressions();
    HashMap<String, ArrayList<Expression>> joinConditions = unionFindBuilder.getJoinConditions();
    HashMap<String, LogicalOperator> logicalSelections = generateLogicalSelections(unionFind);

    ArrayList<Column> combinedSchema = new ArrayList<Column>();
    for (Table table : joinOrder) {
      ArrayList<Column> schema = DBCatalog.getDB().getTableColumns(table.getName());
      combinedSchema.addAll(schema);
    }

    return new LogicalMultiJoin(
        combinedSchema,
        joinOrder,
        joinConditions,
        unionFind,
        residualExpressions,
        logicalSelections,
        vValueManager);
  }

  /**
   * Processes the given join order of the query to generate a tree of join operators. This function
   * will only be executed when join condition exists but the where clause is null. The result will
   * be a cross product product of all the tables listed in the join order.
   *
   * @return root operator of the generated tree.
   */
  public LogicalOperator getCrossProductRootperator(LogicalOperator childOperator) {
    LogicalOperator crossProductRoot = null;
    for (int i = 1; i < joinOrder.size(); i++) {
      Table rightTable = joinOrder.get(i);
      ArrayList<Column> rightSchema = DBCatalog.getDB().getTableColumns(rightTable.getName());
      ArrayList<Column> combinedSchema = new ArrayList<>();
      combinedSchema.addAll(childOperator.getSchema());
      combinedSchema.addAll(rightSchema);

      crossProductRoot =
          new LogicalCrossJoin(combinedSchema, childOperator, new LogicalScan(rightSchema));
    }

    return crossProductRoot;
  }

  /**
   * Sets the parent operator that will be returned by the buildPlan function. The root operator
   * utilizes table operator to get the next tuple.
   */
  public void buildOperatorTree() {
    // Get schema for table mentioned in the 'FROM' clauses:
    String fromTableName = fromTable.getName();
    outputSchema = DBCatalog.getDB().getTableColumns(fromTableName);

    // Create a tree of operators and pass it to the root operator.
    // Inside the root operator, use the passed table operator to
    // Note: scanOperator is a leaf operator i.e. it cannot accept a table operator.
    rootOperator = new LogicalScan(outputSchema);

    // when only the WHERE clause exists set the rootOperator to selectOperator
    if (where != null && joins == null) {
      rootOperator = new LogicalSelect(outputSchema, rootOperator, where);
    } else if (joins != null) {
      joinOrder = new ArrayList<Table>();
      joinOrder.add(fromTable);
      for (Join join : joins) {
        joinOrder.add(((Table) join.getRightItem()));
      }

      // When both WHERE and JOIN clause exists, build the join tree and set the
      // rootOperator
      if (where != null) {
        rootOperator = getRootJoinOperator();
        outputSchema = rootOperator.getSchema();
      } else { // When only JOIN clause exists, evaluate the cross product product.
        for (int i = 1; i < joinOrder.size(); i++) {
          rootOperator = getCrossProductRootperator(rootOperator);
          outputSchema = rootOperator.getSchema();
        }
      }
    }

    // if projections exists, then the rootOperator is set to ProjectOperator
    for (SelectItem selectItem : selectItems) {
      if (selectItem instanceof SelectExpressionItem) {
        LogicalProject projectOperator =
            new LogicalProject(outputSchema, rootOperator, selectItems);
        outputSchema = projectOperator.getSelectColumns();
        rootOperator = (LogicalOperator) projectOperator;
        break;
      }
    }

    // if orderby clause or distinct keyword exists, rootOperator is set to
    // LogicalSort
    if (orderByElements != null || distinct != null) {
      rootOperator = new LogicalSort(outputSchema, rootOperator, orderByElements);
    }

    // if distinct keyword exists, rootOperator is set to LogicalDistinct
    if (distinct != null) {
      rootOperator = new LogicalDistinct(outputSchema, rootOperator);
    }
  }

  /**
   * Top level method to translate statement to logical query plan
   *
   * @param stmt statement to be translated
   * @return the root of the logical query plan
   * @precondition stmt is a Select having a body that is a PlainSelect
   */
  public void setData(Statement stmt) {
    selectStmt = (Select) stmt;
    PlainSelect ps = (PlainSelect) selectStmt.getSelectBody();
    AliasVisitor aliasVisitor = new AliasVisitor();
    aliasVisitor.processQuery(selectStmt);

    selectItems = ps.getSelectItems();
    distinct = ps.getDistinct();
    fromTable = (Table) ps.getFromItem();
    joins = ps.getJoins();
    where = ps.getWhere();
    orderByElements = ps.getOrderByElements();
  }

  /**
   * Top level method to parse SQL query to a logical query plan and convert to a physcial build
   * plan
   *
   * @param stmt statement to be parsed
   * @return the root of the physical query plan
   * @precondition stmt is a Select having a body that is a PlainSelect
   */
  public Operator buildPlan(Statement stmt) {
    setData(stmt);
    buildOperatorTree();

    PhysicalPlanBuilder pb = new PhysicalPlanBuilder();
    pb.visit(rootOperator);
    Operator physicalRootOperator = pb.getCurrentPhysical();
    return physicalRootOperator;
  }

  public void printLogicalPlan(String fileName) {
    FileWriter writer;
    try {
      writer = new FileWriter(fileName + "_logicalplan");
      writer.write(rootOperator.print(0));
      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void printPhysicalPlan(Operator plan, String fileName) {
    FileWriter writer;
    try {
      writer = new FileWriter(fileName + "_physicalplan");
      writer.write(plan.print(0));
      writer.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
