package operator;

import btree.BTreeDeserializer;
import common.Index;
import common.Record;
import common.Tuple;
import java.util.ArrayList;
import net.sf.jsqlparser.schema.Column;
import util.Constants;

/** IndexScanOperator fetches data from a table using a B+ tree index */
public class IndexScanOperator extends Operator {
  private ScanOperator childOperator;
  private Integer lowkey;
  private Integer highkey;
  private Index index;
  private Integer indexColumnNumber;
  private BTreeDeserializer deserializer;
  private Record record;
  private Boolean firstTuple;

  /**
   * Constructs an IndexScanOperator.
   *
   * @param outputSchema the table from which the operator will fetch data
   * @param lowkey the lower bound of the range of keys the operator should fetch data for
   * @param highkey the lower bound of the range of keys the operator should fetch data for
   * @param index the index object for the index the operator will use to fetch data
   */
  public IndexScanOperator(
      ArrayList<Column> outputSchema,
      Operator child,
      Integer lowkey,
      Integer highkey,
      Index index) {
    super(outputSchema);
    this.childOperator = (ScanOperator) child;
    this.lowkey = lowkey;
    this.highkey = highkey;
    this.index = index;
    this.indexColumnNumber = super.getColumnNumberFromSchema(index.getIndexColumn());
    this.deserializer = new BTreeDeserializer(index);
    this.record = deserializer.findFirstRecord(lowkey, highkey);
    this.firstTuple = true;
  }

  /**
   * Get next tuple from index/table.
   *
   * @return next tuple or null if there are no more tuples in the interval [lowkey, highkey]
   */
  public Tuple getNextTuple() {
    if (record == null) return null;

    if (index.isClustered()) {
      if (firstTuple) {
        Tuple tuple = resolveTuple(record);
        firstTuple = false;
        deserializer.close();
        return tuple;
      } else {
        Tuple tuple = childOperator.getNextTuple();
        if (tuple.getElementAtIndex(indexColumnNumber) <= highkey) {
          return tuple;
        }
      }
      return null;
    } else {
      if (record == null) {
        deserializer.close();
        return null;
      }

      // Get the tuple corresponding to the current record
      Tuple tuple = resolveTuple(record);

      // Find the next leaf record within the specified key range
      record = deserializer.getNextRecord(lowkey, highkey);

      return tuple;
    }
  }

  /**
   * Resolve the given record to a tuple by retrieving it from the data file
   *
   * @param record the record containing the pageid and tupleid of the desired tuple
   * @return the tuple at the position indicated by the pageid and tupleid
   */
  private Tuple resolveTuple(Record record) {
    int pagePosition = record.getPageId() * Constants.IO.PAGE_SIZE;
    childOperator.resetToTuple(pagePosition, record.getTupleId());
    return childOperator.getNextTuple();
  }

  /**
   * Resets cursor on operator to the beginning and resets the record to the first record in the
   * interval [lowkey, highkey]
   */
  public void reset() {
    childOperator.reset();
    deserializer.reset(index);
    this.record = deserializer.findFirstRecord(lowkey, highkey);
  }

  public String print(int level) {
    Column column = index.getIndexColumn();
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("IndexScan");
    sb.append("[");
    sb.append(column.getTable().getName() + ", ");
    sb.append(column.getColumnName() + ", ");
    sb.append(lowkey + ", ");
    sb.append(highkey);
    sb.append("]");
    sb.append("\n");
    return sb.toString();
  }
}
