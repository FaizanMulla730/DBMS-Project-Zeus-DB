package operator;

import common.Tuple;
import java.util.ArrayList;
import java.util.Comparator;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Column;
import visitor.JoinVisitor;

/**
 * SortMergeJoinOperator performs a sort-merge join operation between two sorted relations. It takes
 * two sorted input streams, a join condition, and produces joined tuples.
 */
public class SortMergeJoinOperator extends Operator {
  private Operator leftChild;
  private Operator rightChild;
  private Expression joinExpression;
  private JoinVisitor joinVisitor;
  private Tuple leftTuple;
  private Tuple rightTuple;
  private Integer matchIndex;

  /**
   * Initializes the SortMergeJoinOperator with the given input operators and join condition.
   *
   * @param outputSchema the output schema of the join operation.
   * @param leftOperator the left input operator (sorted relation).
   * @param rightOperator the right input operator (sorted relation).
   * @param join the join condition expression.
   */
  public SortMergeJoinOperator(
      ArrayList<Column> outputSchema,
      Operator leftOperator,
      Operator rightOperator,
      Expression join) {
    super(outputSchema);
    this.leftChild = leftOperator;
    this.rightChild = rightOperator;
    this.joinExpression = join;
    this.joinVisitor = new JoinVisitor(leftOperator, rightOperator);
    this.leftTuple = leftChild.getNextTuple();
    this.rightTuple = rightChild.getNextTuple();
    this.matchIndex = 0;
  }

  /** Custom comparator for sorting tuples based on the join condition. */
  public class SMJComparator implements Comparator<Tuple> {
    @Override
    public int compare(Tuple left, Tuple right) {
      joinVisitor.setTuples(left, right);
      joinExpression.accept(joinVisitor);
      if (joinVisitor.getResultCondition()) {
        return 0;
      } else if (joinVisitor.evaluateResultDiff()) {
        return 1;
      } else {
        return -1;
      }
    }
  }

  /**
   * Concatenates the tuples
   *
   * @param lefTuple outer tuple
   * @param rightTuple inner tuple
   * @return joined tuple
   */
  private Tuple joinTuples(Tuple lefTuple, Tuple rightTuple) {
    String lefStringTuple = lefTuple.toString();
    String righStringTuple = rightTuple.toString();

    return new Tuple(lefStringTuple.concat(",").concat(righStringTuple));
  }

  /**
   * Retrieves the next joined tuple using sort merge join algorithm.
   *
   * @return the next joined tuple or null if no more tuples can be joined.
   */
  public Tuple getNextTuple() {
    SMJComparator comparator = new SMJComparator();
    while (leftTuple != null && rightTuple != null) {
      int comparisonResult = comparator.compare(leftTuple, rightTuple);
      if (comparisonResult < 0) {
        // Left tuple is smaller, move to the next left tuple
        leftTuple = leftChild.getNextTuple();
        continue;
      } else if (comparisonResult > 0) {
        // Right tuple is smaller, move to the next right tuple
        rightTuple = rightChild.getNextTuple();
        matchIndex++;
        continue;
      } else if (comparisonResult == 0) {
        // Tuples match on join condition, merge and return the output tuple
        Tuple mergedTuple = joinTuples(leftTuple, rightTuple);
        // Move to the next right tuple
        rightTuple = rightChild.getNextTuple();
        if (rightTuple == null || comparator.compare(leftTuple, rightTuple) != 0) {
          leftTuple = leftChild.getNextTuple();
          rightChild.reset(matchIndex);
          rightTuple = rightChild.getNextTuple();
        }
        return mergedTuple;
      }
    }
    // No more tuples to join
    return null;
  }

  /** Resets the join operator to its initial state, allowing re-processing of input tuples. */
  public void reset() {
    leftChild.reset();
    rightChild.reset();
    leftTuple = leftChild.getNextTuple();
    rightTuple = rightChild.getNextTuple();
    matchIndex = 0;
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("SMJ");
    sb.append("[" + joinExpression.toString() + "]");
    sb.append("\n");
    ++level;
    sb.append(leftChild.print(level));
    sb.append(rightChild.print(level));
    return sb.toString();
  }
}
