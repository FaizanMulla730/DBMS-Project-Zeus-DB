package operator;

import common.Tuple;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javaNIO.TupleWriter;
import net.sf.jsqlparser.schema.Column;

/**
 * Abstract class to represent relational operators. Every operator has a reference to an
 * outputSchema which represents the schema of the output tuples from the operator. This is a list
 * of Column objects. Each Column has an embedded Table object with the name and alias (if required)
 * fields set appropriately.
 */
public abstract class Operator {

  protected ArrayList<Column> outputSchema;
  private TupleWriter tupleWriter;

  public Operator(ArrayList<Column> outputSchema) {
    this.outputSchema = outputSchema;
  }

  public ArrayList<Column> getOutputSchema() {
    return outputSchema;
  }

  /**
   * Get next tuple from operator
   *
   * @return next Tuple, or null if we are at the end
   */
  public abstract Tuple getNextTuple();

  /**
   * Collects all tuples of this operator.
   *
   * @return A list of Tuples.
   */
  public List<Tuple> getAllTuples() {
    Tuple t;
    List<Tuple> tuples = new ArrayList<>();
    while ((t = getNextTuple()) != null) {
      tuples.add(t);
    }

    return tuples;
  }

  /**
   * Get index of the given column from its table's column array.
   *
   * <p>Note: The table's column array is stored in the schema.
   *
   * @param column - column for which index is required
   * @return index of the given column in the table's column array.
   */
  public int getColumnNumberFromSchema(Column column) {
    for (Column schemaColumn : outputSchema) {
      if (column.getColumnName().equals(schemaColumn.getColumnName())
          && column.getTable().getName().equals(schemaColumn.getTable().getName())) {
        return outputSchema.indexOf(schemaColumn);
      }
    }
    return -1;
  }

  /** Iterate through output of operator and send it all to the specified printStream) */
  public void dump(File file) {
    tupleWriter = new TupleWriter(file);
    Tuple t;
    while (true) {
      if ((t = this.getNextTuple()) == null) {
        tupleWriter.close();
        break;
      }
      tupleWriter.writeTuple(t);
    }
  }

  /** Resets cursor on the operator to the beginning */
  public abstract void reset();

  /** Resets cursor on the operator to the given index */
  public void reset(int index) {}

  public abstract String print(int level);
}
