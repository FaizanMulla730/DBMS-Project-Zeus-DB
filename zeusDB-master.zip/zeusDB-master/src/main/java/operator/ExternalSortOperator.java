package operator;

import common.Tuple;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;
import javaNIO.Converter;
import javaNIO.TupleReader;
import javaNIO.TupleWriter;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.OrderByElement;
import util.Constants;
import util.SortComparator;

/**
 * ExternalSortOperator sorts tuples based on the columns in the ORDER BY clause using the external
 * sort algorithm.
 */
public class ExternalSortOperator extends Operator {
  private Operator childOperator;
  private List<OrderByElement> orderBy;
  private String tempDirectory;
  private Integer blockPages;
  private Integer pass;
  private ArrayList<File> sortedRuns;
  private Tuple currentTuple;
  private String timeStamp;
  private Integer blockSize;
  private ArrayList<Tuple> block;
  private TupleReader tupleReader;
  private Converter con;

  /**
   * Constructs an ExternalSortOperator.
   *
   * @param outputSchema the table from which to store data
   * @param child the child of this operator
   * @param orderBy a list containing the names of columns to sort the rows by
   * @param tempDir the path to the file where partially sorted runs will be kept
   * @param blockPages the number of pages in a block
   */
  public ExternalSortOperator(
      ArrayList<Column> outputSchema,
      Operator child,
      List<OrderByElement> orderBy,
      String tempDir,
      int blockPages) {
    super(outputSchema);
    this.childOperator = child;
    this.orderBy = orderBy;
    this.tempDirectory = tempDir;
    this.blockPages = blockPages;
    this.pass = 0;
    this.sortedRuns = new ArrayList<File>();
    this.currentTuple = childOperator.getNextTuple();
    if (currentTuple != null) {
      this.timeStamp = getCurrentTimestamp();
      this.blockSize = calcPageCapacity() * blockPages;
      this.block = new ArrayList<Tuple>(blockSize);

      fillBuffer();
      sort();
      setTupleReader();
    }
  }

  /**
   * Calculates how many tuples of the childOperator can fit on one page
   *
   * @return number of tuples that can fit on a single page, rounded down
   */
  public int calcPageCapacity() {
    int tupleSize = Constants.IO.INT_SIZE * currentTuple.getAllElements().size();
    int pageCapacity = Math.floorDiv(Constants.IO.PAGE_SIZE, tupleSize);
    return pageCapacity;
  }

  /**
   * Fills the buffer with the Tuples obtained from childOperator. Stops when childOperator runs out
   * of rows or the buffer is full.
   */
  public void fillBuffer() {
    block.clear();

    while (currentTuple != null && block.size() < blockSize) {
      block.add(currentTuple);
      currentTuple = childOperator.getNextTuple();
    }
  }

  /**
   * Returns the current timestamp in String format
   *
   * @return current timestamp in "yyyy_MM_dd_HH_mm_ss_SSS" format.
   */
  public String getCurrentTimestamp() {
    LocalDateTime currentDateTime = LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm_ss_SSS");
    return currentDateTime.format(formatter);
  }

  /**
   * Returns the filepath that'll be used to store the temp data for current pass and run
   *
   * @return Filepath for the temporary data file.
   */
  public String getTempFileName() {
    return tempDirectory + "/" + (timeStamp + "_" + pass + "_" + sortedRuns.size());
  }

  /**
   * Returns the filepath that'll be used to store the temp data for the specified pass and run.
   *
   * @param pass The pass number.
   * @param run The run number.
   * @return Filepath for the temporary data file.
   */
  public String getTempFileName(int pass, int run) {
    return tempDirectory + "/" + (timeStamp + "_" + pass + "_" + run);
  }

  /** Merges the sorted runs using external merge sort algorithm. */
  private void merge() {
    Tuple tuple;
    TupleReader reader;
    SortComparator comparator = new SortComparator(orderBy, this);
    PriorityQueue<Tuple> pq = new PriorityQueue<>(comparator);
    ArrayList<File> updatedSortRuns;

    while (sortedRuns.size() > 1) {
      int mergeRunCount = Math.min(blockPages - 1, sortedRuns.size());
      for (int i = 0; i < mergeRunCount; i++) {
        reader = new TupleReader(sortedRuns.get(i));
        while ((tuple = reader.readTuple()) != null) {
          pq.add(tuple);
        }
        reader.close();
      }

      File mergeFile = new File(getTempFileName(pass + 1, 0));
      TupleWriter outputPage = new TupleWriter(mergeFile);
      while (!pq.isEmpty()) {
        tuple = pq.poll();
        outputPage.writeTuple(tuple);
      }
      outputPage.close();
      con = new Converter(mergeFile);
      con.convert();
      updatedSortRuns = new ArrayList<File>();
      updatedSortRuns.add(mergeFile);
      for (int i = mergeRunCount; i < sortedRuns.size(); i++) {
        updatedSortRuns.add(sortedRuns.get(i));
      }
      sortedRuns.clear();
      sortedRuns.addAll(updatedSortRuns);
      pass++;
    }
  }

  /** Sorts the data using external merge sort algorithm. */
  private void sort() {
    SortComparator comparator = new SortComparator(orderBy, this);
    while (!block.isEmpty()) {
      // Sort the block:
      Collections.sort(block, comparator);
      // Write data to the scratch file:
      File tempFile = new File(getTempFileName());
      sortedRuns.add(tempFile);
      TupleWriter tupleWriter = new TupleWriter(tempFile);
      for (Tuple t : block) {
        tupleWriter.writeTuple(t);
      }
      tupleWriter.close();
      con = new Converter(tempFile);
      con.convert();
      // Reload the buffer
      fillBuffer();
    }
    pass++;
    merge();
  }

  /** Sets the TupleReader to read the sorted output. */
  public void setTupleReader() {
    tupleReader = new TupleReader(sortedRuns.get(0));
  }

  /**
   * Retrieves the next tuple from the sorted runs.
   *
   * @return The next tuple from the sorted runs, or null if there are no more tuples.
   */
  public Tuple getNextTuple() {
    if (tupleReader == null) return null;
    return tupleReader.readTuple();
  }

  /** Resets the TupleReader to read from the beginning of the sorted runs. */
  public void reset() {
    tupleReader.reset();
  }

  /**
   * Resets the TupleReader to the specified index position.
   *
   * @param index index position to reset the TupleReader.
   */
  public void reset(int index) {
    // Calculate size of each tuple
    int tupleSize = Constants.IO.INT_SIZE * outputSchema.size();
    // Calculate how many tuples can fit on a page
    int pageCapacity = Math.floorDiv(Constants.IO.PAGE_SIZE, tupleSize);
    // Calculate the reset position for TupleReader
    int resetPage = Math.floorDiv(index, pageCapacity);
    tupleReader.reset(resetPage * Constants.IO.PAGE_SIZE);
    int extraPageTuples = index - resetPage * pageCapacity;
    for (int i = 0; i < extraPageTuples; i++) {
      tupleReader.readTuple();
    }
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    if (orderBy != null) {
      String[] orderByStrs = new String[orderBy.size()];
      for (int i = 0; i < orderBy.size(); i++) {
        orderByStrs[i] = orderBy.get(i).toString();
      }

      sb.append("-".repeat(level));
      sb.append("ExternalSort");
      sb.append("[" + String.join(", ", orderByStrs) + "]");
      sb.append("\n");
      ++level;
    }
    sb.append(childOperator.print(level));
    return sb.toString();
  }
}
