package operator;

import common.Tuple;
import java.util.ArrayList;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Column;
import util.Constants;
import visitor.JoinVisitor;

/**
 * A BlockNestedJoinOperator has a left and right child and joins them according to the BNLJ
 * algorithm.
 */
public class BlockNestedJoinOperator extends Operator {
  private Operator leftChild;
  private Operator rightChild;
  private Expression joinExpression;
  private JoinVisitor joinVisitor;
  private ArrayList<Tuple> block;
  private Tuple leftTuple;
  private Tuple rightTuple;
  private Integer blockSize;
  private Integer blockPosition;

  /**
   * Constructs a BlockNestedJoinOperator.
   *
   * @param outputSchema table from which the BlockNestedJoinOperator will retrieve data.
   * @param blockPages the amount of pages in a block.
   * @param left the left child Operator.
   * @param right the right child Operator.
   * @param exp an Expression representing the join condition.
   */
  public BlockNestedJoinOperator(
      ArrayList<Column> outputSchema,
      int blockPages,
      Operator outer,
      Operator inner,
      Expression exp) {
    super(outputSchema);
    leftChild = outer;
    rightChild = inner;
    joinExpression = exp;
    joinVisitor = new JoinVisitor(outer, inner);
    leftTuple = leftChild.getNextTuple();
    rightTuple = rightChild.getNextTuple();
    blockSize = calcPageCapacity() * blockPages;
    block = new ArrayList<Tuple>(blockSize);

    fillBlock();
  }

  /**
   * Calculates how many tuples of the outer table can fit on one page
   *
   * @return number of tuples that can fit on a single page, rounded down
   */
  public int calcPageCapacity() {
    int tupleSize = Constants.IO.INT_SIZE * leftTuple.getAllElements().size();
    int pageCapacity = Math.floorDiv(Constants.IO.PAGE_SIZE, tupleSize);
    return pageCapacity;
  }

  /**
   * Fills the block with the next Tuples from the outer table. Stops when outer table runs out of
   * rows or the block is full.
   */
  public void fillBlock() {
    block.clear();

    while (leftTuple != null && block.size() < blockSize) {
      block.add(leftTuple);
      leftTuple = leftChild.getNextTuple();
    }

    blockPosition = 0; // For reading tuples
  }

  /**
   * Concatenates the tuples
   *
   * @param leftTuple outer tuple
   * @param rightTuple inner tuple
   * @return joined tuple
   */
  private Tuple joinTuples(Tuple leftTuple, Tuple rightTuple) {
    String leftStringTuple = leftTuple.toString();
    String rightStringTuple = rightTuple.toString();

    return new Tuple(leftStringTuple.concat(",").concat(rightStringTuple));
  }

  /**
   * Gets next pair of Tuples by taking the next Tuple from the current block and the inner table.
   * Checks if the join condition is valid for the pair. If the pair is valid -> returns the pair.
   * Else keeps on interating until the child operators return a valid pair or there are no more
   * pairs.
   *
   * @return valid tuple for the given join condition.
   */
  public Tuple getNextTuple() {
    Tuple result = null;
    Tuple blockTuple = null;

    while (!block.isEmpty()) {
      while (rightTuple != null) {
        while (block.size() > blockPosition) {
          blockTuple = block.get(blockPosition);
          blockPosition++;

          if (joinExpression == null) {
            result = joinTuples(blockTuple, rightTuple);
            return result;
          } else {
            joinVisitor.setTuples(blockTuple, rightTuple);
            joinExpression.accept(joinVisitor);

            if (joinVisitor.getResultCondition()) {
              result = joinTuples(blockTuple, rightTuple);
              return result;
            }
          }
        }

        blockPosition = 0;
        rightTuple = rightChild.getNextTuple();
      }

      rightChild.reset();
      rightTuple = rightChild.getNextTuple();
      fillBlock();
    }
    return null;
  }

  /** Resets cursor by resetting the both left and right children */
  public void reset() {
    leftChild.reset();
    rightChild.reset();
    leftTuple = leftChild.getNextTuple();
    rightTuple = rightChild.getNextTuple();
    fillBlock();
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("BNLJ");
    sb.append("[" + joinExpression.toString() + "]");
    sb.append("\n");
    ++level;
    sb.append(leftChild.print(level));
    sb.append(rightChild.print(level));
    return sb.toString();
  }
}
