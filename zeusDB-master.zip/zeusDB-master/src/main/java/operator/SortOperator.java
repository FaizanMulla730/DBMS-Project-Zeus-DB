package operator;

import common.Tuple;
import java.util.ArrayList;
import java.util.List;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.OrderByElement;
import util.SortComparator;

/**
 * SortOperator sorts tuples based on the ORDER BY clause in the query. If there are ties, then
 * sorts by the original schema order.
 */
public class SortOperator extends Operator {
  private List<OrderByElement> orderBy;
  private ArrayList<Tuple> sortBuffer;
  private Operator childOperator;
  private Integer currentIndex;

  /**
   * Constructs a Sort Operator.
   *
   * @param outputSchema table from which the Sort Operator retrieves data.
   * @param child child of the Sort Operator.
   * @param orderBy List of columns to sort by in order
   */
  public SortOperator(
      ArrayList<Column> outputSchema, Operator child, List<OrderByElement> orderBy) {
    super(outputSchema);
    this.orderBy = orderBy;
    this.childOperator = child;
    this.sortBuffer = new ArrayList<Tuple>();
    this.currentIndex = 0;
    loadSortBuffer();
  }

  /** Loads and sorts the data in the sort buffer from the child operator. */
  public void loadSortBuffer() {
    // Initialize a comparator for sorting.
    SortComparator comparator = new SortComparator(orderBy, this);

    // Load data from the child operator and add it to the sort buffer.
    Tuple currentTuple;
    while ((currentTuple = childOperator.getNextTuple()) != null) {
      sortBuffer.add(currentTuple);
    }

    // Sort the data in the sort buffer using the comparator.
    sortBuffer.sort(comparator);
  }

  /**
   * Retrieves the next tuple from the sorted data.
   *
   * @return the next tuple in the sorted data, or null if there are no more tuples.
   */
  public Tuple getNextTuple() {
    if (sortBuffer.size() > currentIndex) {
      Tuple outTuple = sortBuffer.get(currentIndex);
      currentIndex++;
      return outTuple;
    }
    return null;
  }

  /**
   * Resets the SortOperator by resetting its child operator and currentIndex. This method allows
   * you to start iterating through the sorted data from the beginning.
   */
  public void reset() {
    childOperator.reset();
    currentIndex = 0;
  }

  /**
   * Resets the currentIndex of the sortBuffer to the specified index position.
   *
   * @param index index position to reset the sortBuffer.
   */
  public void reset(int index) {
    currentIndex = index;
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    if (orderBy != null) {
      String[] orderByStrs = new String[orderBy.size()];
      for (int i = 0; i < orderBy.size(); i++) {
        orderByStrs[i] = orderBy.get(i).toString();
      }
      sb.append("-".repeat(level));
      sb.append("Sort");
      sb.append("[" + String.join(", ", orderByStrs) + "]");
      sb.append("\n");
      ++level;
    }
    sb.append(childOperator.print(level));
    return sb.toString();
  }
}
