package operator;

import common.Tuple;
import java.util.ArrayList;
import net.sf.jsqlparser.schema.Column;

/**
 * DuplicateEliminationOperator assumes its input is sorted, reads the tuples from the childOperator
 * and only outputs non-duplicates. Operator needed when there is a DISTINCT keyword in the query.
 */
public class DuplicateEliminationOperator extends Operator {
  private Operator childOperator;
  private Tuple lastTuple = null;
  private Tuple currentTuple = null;

  /**
   * Constructs a DuplicateElimationOperator.
   *
   * @param childOperator childOperator of the DuplicationEliminationOperator.
   * @param outputSchema table from which DuplicationEliminationOperator will retrieve data.
   */
  public DuplicateEliminationOperator(ArrayList<Column> outputSchema, Operator childOperator) {
    super(outputSchema);
    this.childOperator = childOperator;
  }

  /**
   * Get next tuple from childOperator operator and determines whether or not it's duplicate
   *
   * @return next Tuple, or null if we are at the end
   */
  public Tuple getNextTuple() {
    while ((currentTuple = childOperator.getNextTuple()) != null) {
      if (currentTuple.equals(lastTuple)) {
        continue;
      }
      lastTuple = currentTuple;
      return currentTuple;
    }
    return null;
  }

  /** resets the childOperator of this DuplicateEliminationOperator */
  public void reset() {
    childOperator.reset();
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("DupElim");
    sb.append("\n");
    sb.append(childOperator.print(++level));
    return sb.toString();
  }
}
