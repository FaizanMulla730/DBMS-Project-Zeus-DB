package operator;

import common.Tuple;
import java.util.ArrayList;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Column;
import visitor.SelectVisitor;

/**
 * SelectOperator selects tuples by filtering based on the select conditions in WHERE clause of the
 * query (optional).
 */
public class SelectOperator extends Operator {
  private Operator childOperator;
  private Expression where;
  private SelectVisitor selectVisitor;

  /**
   * Constructs a Select Operator.
   *
   * @param outputSchema table from which the Select Operator will retrieve data.
   * @param childOperator child of this SelectOperator.
   * @param whereExpression The select condition from the query
   */
  public SelectOperator(
      ArrayList<Column> outputSchema, Operator childOperator, Expression whereExpression) {
    super(outputSchema);
    this.childOperator = childOperator;
    this.where = whereExpression;
    this.selectVisitor = new SelectVisitor(childOperator);
  }

  /**
   * Gets next Tuple using the child operator's getNextTuple method. Checks if the tuple is valid on
   * the selection condition If the tuple is valid -> returns the tuple. Else keeps on interating
   * till the child operator returns a valid or null tuple.
   *
   * @return valid tuple for the given select condition.
   */
  public Tuple getNextTuple() {
    Tuple currentTuple = childOperator.getNextTuple();

    while (currentTuple != null) {
      // Check if currentTuple passes selection condition:
      selectVisitor.setInputTuple(currentTuple);
      where.accept(selectVisitor);

      if (selectVisitor.getResultCondition()) {
        return currentTuple;
      } else {
        currentTuple = childOperator.getNextTuple();
      }
    }
    return null;
  }

  /** Resets cursor by resetting the child operator */
  public void reset() {
    childOperator.reset();
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("Select");
    sb.append("[" + where.toString() + "]");
    sb.append("\n");
    sb.append(childOperator.print(++level));
    return sb.toString();
  }
}
