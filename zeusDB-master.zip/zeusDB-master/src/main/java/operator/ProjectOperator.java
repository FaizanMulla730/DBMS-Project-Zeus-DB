package operator;

import common.Tuple;
import java.util.ArrayList;
import java.util.List;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.SelectExpressionItem;
import net.sf.jsqlparser.statement.select.SelectItem;

/**
 * ProjectOperator filters tuples based on the fields specified after the SELECT statement. For
 * SELECT * statements, all columns of the tuples are passed through.
 */
public class ProjectOperator extends Operator {
  private Operator childOperator;
  private List<SelectItem> selectItems;
  private ArrayList<Column> selectColumns;
  private ArrayList<Integer> selectColumnNumbers;

  /**
   * Constructs a ProjectOperator.
   *
   * @param outputSchema table from which ProjectOperator will retrieve data.
   * @param childOperator child of this ProjectOperator.
   * @param selectItems list of Items to select.
   */
  public ProjectOperator(
      ArrayList<Column> outputSchema, Operator childOperator, List<SelectItem> selectItems) {
    super(outputSchema);

    this.selectColumns = new ArrayList<Column>();
    this.selectColumnNumbers = new ArrayList<Integer>();
    this.childOperator = childOperator;
    this.selectItems = selectItems;

    setSelectColumns();
    setSelectColumnNumbers();
  }

  /** Filters out all projected columns in the given query and stores them in selectColumns. */
  public void setSelectColumns() {
    for (SelectItem selectItem : selectItems) {
      if (selectItem instanceof SelectExpressionItem) {
        SelectExpressionItem expressionItem = (SelectExpressionItem) selectItem;
        Column column = (Column) expressionItem.getExpression();
        selectColumns.add(column);
      }
    }
  }

  /**
   * For all selected columns get the value of their index from the column array in schema. Stores
   * the indexes in selectColumnNumbers.
   */
  public void setSelectColumnNumbers() {
    for (Column column : selectColumns) {
      selectColumnNumbers.add(getColumnNumberFromSchema(column));
    }
  }

  /**
   * Gets next Tuple using the child operator's getNextTuple method and applies projection on it.
   *
   * @return valid tuple for the given projection.
   */
  public Tuple getNextTuple() {
    Tuple currentTuple = childOperator.getNextTuple();
    if (selectColumnNumbers.isEmpty()) return currentTuple;
    else if (currentTuple != null) {
      ArrayList<Integer> projectedValues = currentTuple.getElementsAtIndexes(selectColumnNumbers);
      return new Tuple(projectedValues);
    }
    return null;
  }

  /** Resets cursor by resetting the child operator */
  public void reset() {
    childOperator.reset();
  }

  public String print(int level) {
    String[] columnStrs = new String[selectItems.size()];
    for (int i = 0; i < selectItems.size(); i++) {
      columnStrs[i] = selectItems.get(i).toString();
    }
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("Project");
    sb.append("[" + String.join(", ", columnStrs) + "]");
    sb.append("\n");
    sb.append(childOperator.print(++level));
    return sb.toString();
  }
}
