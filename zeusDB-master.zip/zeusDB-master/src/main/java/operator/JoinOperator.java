package operator;

import common.Tuple;
import java.util.ArrayList;
import net.sf.jsqlparser.expression.Expression;
import net.sf.jsqlparser.schema.Column;
import visitor.JoinVisitor;

/**
 * JoinOperator contains both a left and right child Operator along with an Expression which
 * represents the join condition
 */
public class JoinOperator extends Operator {
  private Operator leftChild;
  private Operator rightChild;
  private Expression joinExpression;
  private JoinVisitor joinVisitor;
  private Tuple leftTuple;
  private Tuple rightTuple;

  /**
   * Constructs a JoinOperator.
   *
   * @param outputSchema table from which Join Operator will retrieve data.
   * @param leftOperator the left child Operator.
   * @param rightOperator the right child Operator.
   * @param join an Expression representing this particular join condition.
   */
  public JoinOperator(
      ArrayList<Column> outputSchema,
      Operator leftOperator,
      Operator rightOperator,
      Expression join) {
    super(outputSchema);
    this.leftChild = leftOperator;
    this.rightChild = rightOperator;
    this.joinExpression = join;
    this.joinVisitor = new JoinVisitor(leftOperator, rightOperator);
    this.leftTuple = leftChild.getNextTuple();
    this.rightTuple = rightChild.getNextTuple();
  }

  /**
   * Concatenates the tuples
   *
   * @param lefTuple outer tuple
   * @param rightTuple inner tuple
   * @return joined tuple
   */
  private Tuple joinTuples(Tuple lefTuple, Tuple rightTuple) {
    String lefStringTuple = lefTuple.toString();
    String righStringTuple = rightTuple.toString();

    return new Tuple(lefStringTuple.concat(",").concat(righStringTuple));
  }

  /**
   * Gets next pair of Tuples using the child operators' getNextTuple methods. Checks if the join
   * condition is valid for the pair. If the pair is valid -> returns the pair. Else keeps on
   * interating until the child operators return a valid pair or there are no more pairs.
   *
   * @return valid tuple for the given join condition.
   */
  public Tuple getNextTuple() {
    Tuple result = null;
    while (leftTuple != null) {
      while (rightTuple != null) {
        // if join condition exists, check if the current Tuple pair satisfies it
        // otherwise evalute the cartesian product
        if (joinExpression == null) {
          result = joinTuples(leftTuple, rightTuple);
          rightTuple = rightChild.getNextTuple();
          return result;
        }

        joinVisitor.setTuples(leftTuple, rightTuple);
        joinExpression.accept(joinVisitor);

        if (joinVisitor.getResultCondition()) {
          result = joinTuples(leftTuple, rightTuple);
          rightTuple = rightChild.getNextTuple();
          return result;
        } else {
          rightTuple = rightChild.getNextTuple();
        }
      }
      leftTuple = leftChild.getNextTuple();
      // reset scan of right Table and start again
      rightChild.reset();
      rightTuple = rightChild.getNextTuple();
    }
    return null;
  }

  /** Resets cursor by resetting the both left and right children */
  public void reset() {
    leftChild.reset();
    rightChild.reset();
    leftTuple = leftChild.getNextTuple();
    rightTuple = rightChild.getNextTuple();
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("TNLJ");
    sb.append("[" + joinExpression.toString() + "]");
    sb.append("\n");
    ++level;
    sb.append(leftChild.print(level));
    sb.append(rightChild.print(level));
    return sb.toString();
  }
}
