package operator;

import common.DBCatalog;
import common.Tuple;
import java.io.File;
import java.util.ArrayList;
import javaNIO.TupleReader;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.schema.Table;

/** ScanOperator fetches data from a table */
public class ScanOperator extends Operator {
  private Table table;
  private File tableFile;
  protected TupleReader tupleReader;

  /**
   * Constructs a ScanOperator.
   *
   * @param outputSchema table from which the ScanOperator will be retrieving data.
   */
  public ScanOperator(ArrayList<Column> outputSchema) {
    super(outputSchema);

    table = outputSchema.get(0).getTable();
    tableFile = DBCatalog.getDB().getFileForTable(table.getName());
    tupleReader = new TupleReader(tableFile);
  }

  /**
   * Get next tuple from table
   *
   * @return next Tuple, or null if we are at the end
   */
  public Tuple getNextTuple() {
    return tupleReader.readTuple();
  }

  /**
   * Get next page for the table
   *
   * @return Arraylist of tuples on the current page, or null if we are at the end of the file
   */
  public ArrayList<Tuple> getNextPage() {
    return tupleReader.readPage();
  }

  /** Resets cursor on the operator to the beginning */
  public void reset() {
    tupleReader.reset();
  }

  /**
   * Resets the tuple reader to a specific tuple within a specified page. Moves the tuple reader's
   * position to the specified page and reads tuples until the desired tuple number is reached.
   *
   * @param pagePosition The position of the target page to reset the tuple reader to.
   * @param tupleNumber The number of the target tuple within the specified page.
   */
  public void resetToTuple(int pagePosition, int tupleNumber) {
    tupleReader.reset(pagePosition);
    for (int i = 0; i < tupleNumber; i++) {
      tupleReader.readTuple();
    }
  }

  public String print(int level) {
    StringBuilder sb = new StringBuilder();
    sb.append("-".repeat(level));
    sb.append("TableScan");
    sb.append("[" + outputSchema.get(0).getTable().getName() + "]");
    sb.append("\n");
    return sb.toString();
  }
}
