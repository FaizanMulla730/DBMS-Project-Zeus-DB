package union_find;

import java.util.ArrayList;
import net.sf.jsqlparser.schema.Column;

public class UnionFind {
  private ArrayList<Element> elements;

  public UnionFind() {
    this.elements = new ArrayList<Element>();
  }

  public Element merge(Element ele_a, Element ele_b) {
    for (Column col : ele_b.getAttributes()) {
      if (!ele_a.containsAttribute(col)) {
        ele_a.addAttribute(col);
      }
    }

    // Set lower bound:
    if (ele_a.getLowerBound() != null && ele_b.getLowerBound() != null) {
      if (ele_a.getLowerBound() < ele_b.getLowerBound()) {
        ele_a.setLowerBound(ele_b.getLowerBound());
      }
    } else if (ele_b.getLowerBound() != null) {
      ele_a.setLowerBound(ele_b.getLowerBound());
    }

    // Set upper bound:
    if (ele_a.getUpperBound() != null && ele_b.getUpperBound() != null) {
      if (ele_a.getUpperBound() > ele_b.getUpperBound()) {
        ele_a.setUpperBound(ele_b.getUpperBound());
      }
    } else if (ele_b.getUpperBound() != null) {
      ele_a.setUpperBound(ele_b.getUpperBound());
    }

    // Set equality condition:
    if (ele_a.getEqualityConstraint() == null && ele_b.getEqualityConstraint() != null) {
      ele_a.setEqualityConstraint(ele_b.getEqualityConstraint());
    }

    return ele_a;
  }

  public Element find(Column attribute) {
    for (Element ele : elements) {
      if (ele.containsAttribute(attribute)) {
        return ele;
      }
    }
    return null;
  }

  public Element create(Column attribute) {
    Element ele = find(attribute);
    if (ele != null) return ele;
    else {
      ele = new Element(attribute);
      elements.add(ele);
      return ele;
    }
  }

  public void union(Element ele_a, Element ele_b) {
    elements.add(merge(ele_a, ele_b));
    elements.remove(ele_a);
    elements.remove(ele_b);
  }

  public void setElementLowerBound(Element element, int lowerBound) {
    for (Element ele : elements) {
      if (ele.equals(element)) {
        if (ele.getLowerBound() == null) {
          ele.setLowerBound(lowerBound);
        } else if (ele.getLowerBound() < lowerBound) {
          ele.setLowerBound(lowerBound);
        }
      }
    }
  }

  public void setElementUpperBound(Element element, int upperBound) {
    for (Element ele : elements) {
      if (ele.equals(element)) {
        if (ele.getUpperBound() == null) {
          ele.setUpperBound(upperBound);
        } else if (ele.getUpperBound() > upperBound) {
          ele.setUpperBound(upperBound);
        }
      }
    }
  }

  public void setElementEqualityConstraint(Element element, int equalityConstraint) {
    for (Element ele : elements) {
      if (ele.equals(element)) {
        ele.setEqualityConstraint(equalityConstraint);
      }
    }
  }

  public String print() {
    StringBuilder sb = new StringBuilder();
    for (Element ele : elements) {
      sb.append(ele.print());
      sb.append("\n");
    }
    return sb.toString();
  }
}
