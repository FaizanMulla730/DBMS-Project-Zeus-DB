package union_find;

import java.util.ArrayList;
import net.sf.jsqlparser.schema.Column;

public class Element {
  private ArrayList<Column> attributes;
  private Integer lowerBound;
  private Integer upperBound;
  private Integer equalityConstraint;

  public Element(Column attribute) {
    this.attributes = new ArrayList<Column>();
    this.attributes.add(attribute);
  }

  public ArrayList<Column> getAttributes() {
    return attributes;
  }

  public Integer getLowerBound() {
    return lowerBound;
  }

  public Integer getUpperBound() {
    return upperBound;
  }

  public Integer getEqualityConstraint() {
    return equalityConstraint;
  }

  public void setAttributes(ArrayList<Column> attributes) {
    this.attributes = attributes;
  }

  public void setLowerBound(int lowerBound) {
    this.lowerBound = lowerBound;
  }

  public void setUpperBound(int upperBound) {
    this.upperBound = upperBound;
  }

  public void setEqualityConstraint(int equalityConstraint) {
    this.equalityConstraint = equalityConstraint;
  }

  public Boolean containsAttribute(Column attribute) {
    for (Column col : attributes) {
      if (col.getColumnName().equals(attribute.getColumnName())
          && col.getTable().getName().equals(attribute.getTable().getName())) {
        return true;
      }
    }
    return false;
  }

  public void addAttribute(Column attribute) {
    attributes.add(attribute);
  }

  public String print() {
    String[] attributeStrs = new String[attributes.size()];
    for (int i = 0; i < attributes.size(); i++) {
      attributeStrs[i] = attributes.get(i).toString();
    }
    StringBuilder sb = new StringBuilder();
    sb.append("[");
    sb.append("[");
    sb.append(String.join(", ", attributeStrs));
    sb.append("]");
    sb.append(", ");
    sb.append("equals " + equalityConstraint);
    sb.append(", ");
    sb.append("min " + lowerBound);
    sb.append(", ");
    sb.append("max " + upperBound);
    sb.append("]");
    return sb.toString();
  }
}
