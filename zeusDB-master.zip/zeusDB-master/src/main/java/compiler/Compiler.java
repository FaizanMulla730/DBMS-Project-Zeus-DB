package compiler;

import builder.IndexBuilder;
import builder.QueryPlanBuilder;
import common.DBCatalog;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import javaNIO.Converter;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.Statements;
import operator.Operator;
import util.Generator;
import util.Tracker;

/**
 * Top level harness class: Reads queries from an input file one at a time sequentially processes
 * each query and sends the output to file or to System depending on the System flag.
 */
public class Compiler {
  private static String inputDir;
  private static String outputDir;
  private static String tempDir;
  private static Boolean benchmarkingMode;

  public static void cleanDirectory(String path) {
    for (File file : (new File(path).listFiles())) file.delete();
  }

  public static void setCompilerConfig(String configFilePath) {
    try {
      BufferedReader br = new BufferedReader(new FileReader(configFilePath));
      inputDir = br.readLine();
      outputDir = br.readLine();
      tempDir = br.readLine();
      // Set this to true if you want to generate random data:
      benchmarkingMode = false;
      br.close();
    } catch (Exception e) {
      System.out.println("Exception occurred while initializing Compiler config!");
      e.printStackTrace();
    }
  }

  /**
   * Reads statements from the queriesFile one at a time. Builds a query plan and evaluate the
   * query. Dumps the results to files or console as desired.
   *
   * <p>While dumping the output to file, result of ith query will be stored using the file name
   * 'queryi'. Note: the index 'i' starts from 1.
   */
  public static void main(String[] args) {
    setCompilerConfig(args[0]);

    // Initialize the database catalog:
    DBCatalog.getDB().setDBCatalog(inputDir, tempDir);

    // If benchmarking mode is on generate random tabledata:
    Generator generator = null;
    if (benchmarkingMode) {
      generator = new Generator();
      generator.generateRandomTableData();
    }

    // Create indexes:
    IndexBuilder indexBuilder = new IndexBuilder();
    indexBuilder.createIndexes();

    try {
      cleanDirectory(outputDir); // clean output directory
      Tracker tracker = new Tracker(); // initialize tracker:
      String str = Files.readString(Path.of(inputDir + "/queries.sql"));
      Statements statements = CCJSqlParserUtil.parseStatements(str);
      QueryPlanBuilder queryPlanBuilder = new QueryPlanBuilder();

      int counter = 1; // initialize counter for numbering output files
      for (Statement statement : statements.getStatements()) {
        System.out.println("Processing query: " + statement);

        try {
          tracker.startTracking();
          Operator plan = queryPlanBuilder.buildPlan(statement);
          String outFileName = outputDir + "/query" + counter;
          File outfile = new File(outFileName);
          plan.dump(outfile);
          tracker.endTracking(statement.toString());
          // Print plans:
          queryPlanBuilder.printLogicalPlan(outFileName);
          queryPlanBuilder.printPhysicalPlan(plan, outFileName);
          // Convert output to humanreadible format
          Converter con = new Converter(outfile);
          con.convert();
        } catch (Exception e) {
          System.out.println(
              "Exception occurred while processing query: " + statement + "\n" + e.getMessage());
          e.printStackTrace();
        }

        ++counter;
      }

      cleanDirectory(tempDir); // clean temp directory
    } catch (Exception e) {
      System.err.println("Exception occurred in interpreter");
      System.out.println(e.getMessage());
      e.printStackTrace();
    }
  }
}
