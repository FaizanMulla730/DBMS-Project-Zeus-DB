package util;

import common.Tuple;
import java.util.Comparator;
import java.util.List;
import net.sf.jsqlparser.schema.Column;
import net.sf.jsqlparser.statement.select.OrderByElement;
import operator.Operator;

/** Private class to implement a comparator that orders tuples in ascending order */
public class SortComparator implements Comparator<Tuple> {
  List<OrderByElement> orderBy;
  Operator sortOperator;

  public SortComparator(List<OrderByElement> orderBy, Operator operator) {
    this.orderBy = orderBy;
    this.sortOperator = operator;
  }

  /**
   * Compares the values in the two tuples based on the columns to sort by. If equal, moves to next
   * column in order by clause. If all columns equal return 0.
   *
   * @param leftTuple The first tuple
   * @param rightTuple The second tuple
   */
  public int compare(Tuple leftTuple, Tuple rightTuple) {
    if (orderBy != null) {
      for (OrderByElement column : orderBy) {
        int columnIndex = sortOperator.getColumnNumberFromSchema((Column) column.getExpression());
        int leftColumnValue = leftTuple.getElementAtIndex(columnIndex);
        int rightColumnValue = rightTuple.getElementAtIndex(columnIndex);

        if (leftColumnValue != rightColumnValue) {
          return Integer.compare(leftColumnValue, rightColumnValue);
        }
      }
    }

    // If all columns in the orderBy clause are equal, compare remaining columns
    for (int i = 0; i < leftTuple.getAllElements().size(); i++) {
      int leftRemainingColumnValue = leftTuple.getElementAtIndex(i);
      int rightRemainingColumnValue = rightTuple.getElementAtIndex(i);

      if (leftRemainingColumnValue != rightRemainingColumnValue) {
        return Integer.compare(leftRemainingColumnValue, rightRemainingColumnValue);
      }
    }

    return 0;
  }
}
