package util;

import common.DBCatalog;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Tracker class for tracking query execution time and writing data to a CSV file. */
public class Tracker {
  private static final String CSV_FILE_NAME = "/tracker.csv";
  private static final String CSV_FILE_COLS = "query,time\n";
  private Long startTime;
  private String csvPath;

  /** Initializes the Tracker object and CSV file if it does not exist. */
  public Tracker() {
    startTime = (long) 0;
    initCSV();
  }

  /** Initializes the CSV file by creating the file and writing header if it doesn't exist. */
  public void initCSV() {
    try {
      csvPath = DBCatalog.getDB().getDBDirectory() + CSV_FILE_NAME;

      File csvFile = new File(csvPath);
      if (!csvFile.exists()) {
        try (FileWriter writer = new FileWriter(csvFile)) {
          writer.append(CSV_FILE_COLS);
        }
      }
    } catch (IOException e) {
      System.out.println(
          "Error while initializing CSV for tracking performance: " + e.getMessage());
      e.printStackTrace();
    } catch (Exception e) {
      System.out.println("Unexpected error: " + e.getMessage());
      e.printStackTrace();
    }
  }

  /** Starts tracking the execution time of a query. */
  public void startTracking() {
    startTime = System.currentTimeMillis();
  }

  /**
   * Returns the current timestamp in String format.
   *
   * @return current timestamp in "yyyy_MM_dd_HH_mm_ss_SSS" format.
   */
  public String getCurrentTimestamp() {
    LocalDateTime currentDateTime = LocalDateTime.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy_MM_dd_HH_mm_ss_SSS");
    return currentDateTime.format(formatter);
  }

  /**
   * Writes query execution data to the CSV file.
   *
   * @param query the query being tracked.
   * @param executionTime the execution time of the query in milliseconds.
   */
  public void writeDataToCSV(String query, long executionTime) {
    try (FileWriter writer = new FileWriter(csvPath, true)) {
      // Append execution time to the CSV file
      writer.append(query);
      writer.append(",");
      writer.append(String.valueOf(executionTime));
      writer.append("\n");
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  /**
   * Ends tracking for the given query and writes data to the CSV file.
   *
   * @param query the query being tracked.
   */
  public void endTracking(String query) {
    try {
      long executionTime = System.currentTimeMillis() - startTime;
      writeDataToCSV(query, executionTime);
    } catch (Exception e) {
      System.out.println("Error while tracking query performance: " + query);
      e.printStackTrace();
    }
  }
}
