package util;

/**
 * Constants contains public classes encoding constants used in other classes, such as the number of
 * bytes that can fit on a page.
 */
public class Constants {

  /** IO contains constants relevant to IO operations. */
  public class IO {
    public static final int PAGE_SIZE = 4096;
    public static final int INT_SIZE = 4;
  }

  /** Join contains constants relevant to parsing the different types of join operations. */
  public class Join {
    public static final String TNLJ = "TNLJ";
    public static final String BNLJ = "BNLJ";
    public static final String SMJ = "SMJ";
    public static final int PAGES = 3;
  }

  /** Sort contains constants relevant to parsing the different sort types from the config file. */
  public class Sort {
    public static final String IN_MEM = "inMem";
    public static final String EXTERNAL = "external";
    public static final int PAGES = 3;
  }

  // Private constructor to prevent instantiation of the Constants class
  private Constants() {
    // This constructor is empty to prevent instantiation
  }
}
