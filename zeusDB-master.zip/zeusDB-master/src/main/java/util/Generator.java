package util;

import common.DBCatalog;
import common.Tuple;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javaNIO.Converter;
import javaNIO.TupleWriter;
import net.sf.jsqlparser.schema.Column;

/** Generates random data for all tables in the database catalog. */
public class Generator {
  private Random random;
  private HashMap<String, ArrayList<Column>> tables;

  /** Initializes a random number generator and schemas from the database catalog. */
  public Generator() {
    random = new Random();
    tables = DBCatalog.getDB().getAllTables();
  }

  /**
   * Generates a random tuple with the specified number of columns.
   *
   * @param size the number of columns in the tuple.
   * @return Tuple object with random integer values.
   */
  private Tuple generateRandomTuple(int size) {
    ArrayList<Integer> randomArrayList = new ArrayList<>();

    for (int i = 0; i < size; i++) {
      randomArrayList.add(random.nextInt(100));
    }

    return new Tuple(randomArrayList);
  }

  /**
   * Generates random data for all tables in DBCatalog and writes it to the corresponding table
   * files.
   */
  public void generateRandomTableData() {
    for (Map.Entry<String, ArrayList<Column>> table : tables.entrySet()) {
      String tableName = table.getKey();
      File tableFile = DBCatalog.getDB().getFileForTable(tableName);
      TupleWriter writer = new TupleWriter(tableFile);
      int numCols = table.getValue().size();
      int tableSize = random.nextInt(2000) + 5000;

      for (int i = 0; i < tableSize; i++) {
        writer.writeTuple(generateRandomTuple(numCols));
      }

      writer.close();

      Converter con = new Converter(tableFile);
      con.convert();
    }
  }
}
