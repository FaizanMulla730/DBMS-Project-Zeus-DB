package util;

import common.DBCatalog;
import common.TableStats;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import net.sf.jsqlparser.schema.Column;

public class StatsWriter {
  private static final String STATS_FILE_NAME = "/stats.txt";
  private String filePath;

  public StatsWriter() {
    filePath = DBCatalog.getDB().getDBDirectory() + STATS_FILE_NAME;
    initStatsFile();
  }

  public void initStatsFile() {
    try {
      File statsFile = new File(filePath);
      if (!statsFile.exists()) {
        statsFile.createNewFile();
      } else {
        // Clear file content if it exists:
        FileWriter writer = new FileWriter(statsFile);
        writer.close();
      }
    } catch (IOException e) {
      System.out.println(
          "Error while initializing CSV for table statistics at "
              + filePath
              + ": "
              + e.getMessage());
      e.printStackTrace();
    } catch (Exception e) {
      System.out.println("Unexpected error while initializing CSV: " + e.getMessage());
      e.printStackTrace();
    }
  }

  public void writeTableStatsToFile(TableStats stats) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(stats.getTableName());
    stringBuilder.append(" ");
    stringBuilder.append(stats.getSize());

    Column currentColumn;
    for (int i = 0; i < stats.getOutputSchema().size(); i++) {
      stringBuilder.append(" ");
      currentColumn = stats.getOutputSchema().get(i);
      stringBuilder.append(currentColumn.getColumnName());
      stringBuilder.append(",");
      stringBuilder.append(stats.getColumnStats().get(currentColumn)[0]);
      stringBuilder.append(",");
      stringBuilder.append(stats.getColumnStats().get(currentColumn)[1]);
    }
    stringBuilder.append("\n");

    try (FileWriter writer = new FileWriter(filePath, true)) {
      writer.append(stringBuilder.toString());
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
