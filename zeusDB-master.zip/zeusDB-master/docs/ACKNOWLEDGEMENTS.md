# References:

- [Youtube Video](https://www.youtube.com/watch?v=UQP5XqMqtqQ) by [Geekific](https://www.youtube.com/@geekific) for Visitor Class.
- [Youtube Video](https://www.youtube.com/watch?v=pL4mOUDi54o) by [Derek Banas](https://www.youtube.com/@derekbanas) for Visitor Class.
- [JSQLParser Documentation](https://github.com/JSQLParser/JSqlParser)
